CREATE DATABASE  IF NOT EXISTS `umbraco6` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `umbraco6`;
-- MySQL dump 10.14  Distrib 5.5.31-MariaDB, for Linux (i686)
--
-- Host: localhost    Database: umbraco6
-- ------------------------------------------------------
-- Server version	5.5.31-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cmsdocumenttype`
--

DROP TABLE IF EXISTS `cmsdocumenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsdocumenttype` (
  `contentTypeNodeId` int(11) NOT NULL,
  `templateNodeId` int(11) NOT NULL,
  `IsDefault` tinyint(1) NOT NULL DEFAULT '0',
  KEY `contentTypeNodeId` (`contentTypeNodeId`),
  KEY `templateNodeId` (`templateNodeId`),
  CONSTRAINT `cmsdocumenttype_ibfk_1` FOREIGN KEY (`contentTypeNodeId`) REFERENCES `umbraconode` (`id`),
  CONSTRAINT `cmsdocumenttype_ibfk_2` FOREIGN KEY (`contentTypeNodeId`) REFERENCES `cmscontenttype` (`nodeId`),
  CONSTRAINT `cmsdocumenttype_ibfk_3` FOREIGN KEY (`templateNodeId`) REFERENCES `cmstemplate` (`nodeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsdocumenttype`
--

LOCK TABLES `cmsdocumenttype` WRITE;
/*!40000 ALTER TABLE `cmsdocumenttype` DISABLE KEYS */;
INSERT INTO `cmsdocumenttype` VALUES (1058,1059,1),(1072,1073,1);
/*!40000 ALTER TABLE `cmsdocumenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmspropertydata`
--

DROP TABLE IF EXISTS `cmspropertydata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmspropertydata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contentNodeId` int(11) NOT NULL,
  `versionId` char(36) DEFAULT NULL,
  `propertytypeid` int(11) NOT NULL,
  `dataInt` int(11) DEFAULT NULL,
  `dataDate` timestamp NULL DEFAULT NULL,
  `dataNvarchar` varchar(500) DEFAULT NULL,
  `dataNtext` longtext,
  PRIMARY KEY (`id`),
  KEY `IX_cmsPropertyData` (`id`),
  KEY `IX_cmsPropertyData_1` (`contentNodeId`),
  KEY `IX_cmsPropertyData_2` (`versionId`),
  KEY `IX_cmsPropertyData_3` (`propertytypeid`),
  CONSTRAINT `cmspropertydata_ibfk_1` FOREIGN KEY (`contentNodeId`) REFERENCES `umbraconode` (`id`),
  CONSTRAINT `cmspropertydata_ibfk_2` FOREIGN KEY (`propertytypeid`) REFERENCES `cmspropertytype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmspropertydata`
--

LOCK TABLES `cmspropertydata` WRITE;
/*!40000 ALTER TABLE `cmspropertydata` DISABLE KEYS */;
INSERT INTO `cmspropertydata` VALUES (2,1045,'c5f79643-2946-481f-977e-a13ae76e2781',27,NULL,NULL,NULL,NULL),(3,1046,'f3d1d3d1-a0d2-43f1-b139-ba25ca3a2b88',24,NULL,NULL,'/media/1003/2.txt',NULL),(4,1046,'f3d1d3d1-a0d2-43f1-b139-ba25ca3a2b88',25,NULL,NULL,'txt',NULL),(5,1046,'f3d1d3d1-a0d2-43f1-b139-ba25ca3a2b88',26,NULL,NULL,'8482',NULL),(6,1047,'a8f55890-b9fb-4960-8cb2-d9751e9e32d9',6,NULL,NULL,'/media/1004/aboutnew.png',NULL),(7,1047,'a8f55890-b9fb-4960-8cb2-d9751e9e32d9',7,NULL,NULL,'16',NULL),(8,1047,'a8f55890-b9fb-4960-8cb2-d9751e9e32d9',8,NULL,NULL,'16',NULL),(9,1047,'a8f55890-b9fb-4960-8cb2-d9751e9e32d9',9,NULL,NULL,'1178',NULL),(10,1047,'a8f55890-b9fb-4960-8cb2-d9751e9e32d9',10,NULL,NULL,'png',NULL),(11,1048,'01a99380-cbeb-4812-a542-a50ac8b97793',27,NULL,NULL,NULL,NULL),(12,1049,'65f94eff-9085-4072-96b3-18bae92f9507',6,NULL,NULL,'/media/1005/arrowDown.gif',NULL),(13,1049,'65f94eff-9085-4072-96b3-18bae92f9507',7,NULL,NULL,'20',NULL),(14,1049,'65f94eff-9085-4072-96b3-18bae92f9507',8,NULL,NULL,'7',NULL),(15,1049,'65f94eff-9085-4072-96b3-18bae92f9507',9,NULL,NULL,'832',NULL),(16,1049,'65f94eff-9085-4072-96b3-18bae92f9507',10,NULL,NULL,'gif',NULL),(17,1050,'223b5063-bfd2-43df-8415-a52bfa3ce4d0',6,NULL,NULL,'/media/1006/arrowForward.gif',NULL),(18,1050,'223b5063-bfd2-43df-8415-a52bfa3ce4d0',7,NULL,NULL,'7',NULL),(19,1050,'223b5063-bfd2-43df-8415-a52bfa3ce4d0',8,NULL,NULL,'20',NULL),(20,1050,'223b5063-bfd2-43df-8415-a52bfa3ce4d0',9,NULL,NULL,'834',NULL),(21,1050,'223b5063-bfd2-43df-8415-a52bfa3ce4d0',10,NULL,NULL,'gif',NULL),(22,1051,'e2de6479-00ff-4800-9f50-d13ad6cb6aba',6,NULL,NULL,'/media/1007/audit.png',NULL),(23,1051,'e2de6479-00ff-4800-9f50-d13ad6cb6aba',7,NULL,NULL,'16',NULL),(24,1051,'e2de6479-00ff-4800-9f50-d13ad6cb6aba',8,NULL,NULL,'16',NULL),(25,1051,'e2de6479-00ff-4800-9f50-d13ad6cb6aba',9,NULL,NULL,'897',NULL),(26,1051,'e2de6479-00ff-4800-9f50-d13ad6cb6aba',10,NULL,NULL,'png',NULL),(27,1052,'322a3efd-369b-4c57-869b-13f501238ce7',6,NULL,NULL,'/media/1008/back.png',NULL),(28,1052,'322a3efd-369b-4c57-869b-13f501238ce7',7,NULL,NULL,'16',NULL),(29,1052,'322a3efd-369b-4c57-869b-13f501238ce7',8,NULL,NULL,'16',NULL),(30,1052,'322a3efd-369b-4c57-869b-13f501238ce7',9,NULL,NULL,'422',NULL),(31,1052,'322a3efd-369b-4c57-869b-13f501238ce7',10,NULL,NULL,'png',NULL),(32,1061,'c7db23da-ab44-49e7-84d5-c231ac9e44d6',28,NULL,NULL,'',NULL),(33,1061,'c7db23da-ab44-49e7-84d5-c231ac9e44d6',29,NULL,NULL,NULL,''),(34,1061,'5d9ea0d1-dedc-4b7a-aa3d-a3bffd0e92bf',28,NULL,NULL,'',NULL),(35,1061,'5d9ea0d1-dedc-4b7a-aa3d-a3bffd0e92bf',29,NULL,NULL,NULL,''),(36,1061,'a60121ff-c9fe-4943-af9e-405c3921e911',28,NULL,NULL,'',NULL),(37,1061,'a60121ff-c9fe-4943-af9e-405c3921e911',29,NULL,NULL,NULL,''),(38,1061,'60833a6b-0a5d-4ccc-9dfd-213e979dbe7d',28,NULL,NULL,'',NULL),(39,1061,'60833a6b-0a5d-4ccc-9dfd-213e979dbe7d',29,NULL,NULL,NULL,''),(40,1061,'56f2c2d1-9ac9-4b80-bfe7-25c9b5da2ba3',28,NULL,NULL,'',NULL),(41,1061,'56f2c2d1-9ac9-4b80-bfe7-25c9b5da2ba3',29,NULL,NULL,NULL,''),(42,1061,'88a2ee4e-151f-42cb-9813-3260764d726a',28,NULL,NULL,'',NULL),(43,1061,'88a2ee4e-151f-42cb-9813-3260764d726a',29,NULL,NULL,NULL,''),(44,1061,'46640e05-3bae-47f7-aa3d-ac9f3e5a1d8e',28,NULL,NULL,'Page Title',NULL),(45,1061,'46640e05-3bae-47f7-aa3d-ac9f3e5a1d8e',29,NULL,NULL,NULL,''),(46,1061,'781abae0-2b45-4688-bffe-c86c3042b76a',28,NULL,NULL,'Page Title',NULL),(47,1061,'781abae0-2b45-4688-bffe-c86c3042b76a',29,NULL,NULL,NULL,''),(48,1061,'821e4fb6-a6f5-417e-a407-2de56b7c28fb',28,NULL,NULL,'Page Title',NULL),(49,1061,'821e4fb6-a6f5-417e-a407-2de56b7c28fb',29,NULL,NULL,NULL,'<p>This is some text</p>'),(50,1061,'18c2505e-84e7-401a-884d-298eb1a4507e',28,NULL,NULL,'Page Title',NULL),(51,1061,'18c2505e-84e7-401a-884d-298eb1a4507e',29,NULL,NULL,NULL,'<p>This is some text</p>'),(52,1061,'dc5f75e6-2ddb-4bcf-8758-463db624e4d7',28,NULL,NULL,'Page Title',NULL),(53,1061,'dc5f75e6-2ddb-4bcf-8758-463db624e4d7',29,NULL,NULL,NULL,'<p>This is some text</p>'),(54,1061,'7bf4385c-7b56-44eb-9005-9507745bcf58',28,NULL,NULL,'Page Title',NULL),(55,1061,'7bf4385c-7b56-44eb-9005-9507745bcf58',29,NULL,NULL,NULL,'<p>This is some text</p>'),(56,1062,'5790c3f9-2e45-4515-90b9-3159806b903d',28,NULL,NULL,'About us',NULL),(57,1062,'5790c3f9-2e45-4515-90b9-3159806b903d',29,NULL,NULL,NULL,'<p>This is the about us page.</p>'),(58,1062,'8c96354b-8823-4645-8e74-9d926640bb91',28,NULL,NULL,'About us',NULL),(59,1062,'8c96354b-8823-4645-8e74-9d926640bb91',29,NULL,NULL,NULL,'<p>This is the about us page.</p>'),(60,1062,'fff8f575-7681-4e14-9352-79e880e66ad3',28,NULL,NULL,'About us',NULL),(61,1062,'fff8f575-7681-4e14-9352-79e880e66ad3',29,NULL,NULL,NULL,'<p>This is the about us page.</p>'),(62,1062,'54a32d32-f50e-4adf-965c-1a772772295a',28,NULL,NULL,'About us',NULL),(63,1062,'54a32d32-f50e-4adf-965c-1a772772295a',29,NULL,NULL,NULL,'<p>This is the about us page.</p>'),(64,1063,'c8f3842a-c66d-4930-9ace-6825f8b35581',28,NULL,NULL,'Contact Us',NULL),(65,1063,'c8f3842a-c66d-4930-9ace-6825f8b35581',29,NULL,NULL,NULL,'<p>Contact Us page</p>'),(66,1063,'9d99984a-4155-4fd4-9fe4-554eab6b6c9e',28,NULL,NULL,'Contact Us',NULL),(67,1063,'9d99984a-4155-4fd4-9fe4-554eab6b6c9e',29,NULL,NULL,NULL,'<p>Contact Us page</p>'),(68,1064,'14ae6a88-02ff-47b2-9157-d16b657ea5f8',28,NULL,NULL,'Products',NULL),(69,1064,'14ae6a88-02ff-47b2-9157-d16b657ea5f8',29,NULL,NULL,NULL,'<p>Products Page List</p>'),(70,1064,'2efd1b7c-3c27-44bd-bb2a-0d0369832d35',28,NULL,NULL,'Products',NULL),(71,1064,'2efd1b7c-3c27-44bd-bb2a-0d0369832d35',29,NULL,NULL,NULL,'<p>Products Page List</p>'),(76,1066,'1bb58018-edb1-4fcf-a4c8-b32356183262',28,NULL,NULL,'Our Business',NULL),(77,1066,'1bb58018-edb1-4fcf-a4c8-b32356183262',29,NULL,NULL,NULL,'<p>Our Business page</p>'),(78,1066,'1495b5f7-8c2a-42e1-9f46-55cf6089d7d7',28,NULL,NULL,'Our Business',NULL),(79,1066,'1495b5f7-8c2a-42e1-9f46-55cf6089d7d7',29,NULL,NULL,NULL,'<p>Our Business page</p>'),(80,1066,'3eeb8f28-afe7-41d3-b36f-684f4d66ee1c',28,NULL,NULL,'Our Business',NULL),(81,1066,'3eeb8f28-afe7-41d3-b36f-684f4d66ee1c',29,NULL,NULL,NULL,'<p>Our Business page</p>'),(82,1067,'2374f9d1-f242-4fae-a57e-fae68dc55b80',28,NULL,NULL,'Our Head Office',NULL),(83,1067,'2374f9d1-f242-4fae-a57e-fae68dc55b80',29,NULL,NULL,NULL,'<p>Head office page</p>'),(84,1067,'4927a34d-9d43-4d0f-8c8d-a3a226f42404',28,NULL,NULL,'Our Head Office',NULL),(85,1067,'4927a34d-9d43-4d0f-8c8d-a3a226f42404',29,NULL,NULL,NULL,'<p>Head office page</p>'),(86,1063,'1900974f-075b-4d69-8e7f-a2ce06956b83',28,NULL,NULL,'Contact Us',NULL),(87,1063,'1900974f-075b-4d69-8e7f-a2ce06956b83',29,NULL,NULL,NULL,'<p>Contact Us page</p>'),(88,1063,'65affbce-3499-46f2-9172-d4fd4e2be979',28,NULL,NULL,'Contact Us',NULL),(89,1063,'65affbce-3499-46f2-9172-d4fd4e2be979',29,NULL,NULL,NULL,'<p>Contact Us page</p>'),(90,1062,'42de697d-2d07-411e-841f-8e897e0e90d0',28,NULL,NULL,'About us',NULL),(91,1062,'42de697d-2d07-411e-841f-8e897e0e90d0',29,NULL,NULL,NULL,'<p>This is the about us page.</p>'),(92,1062,'88727743-7961-479c-a4e7-14a14365ca0a',28,NULL,NULL,'About us',NULL),(93,1062,'88727743-7961-479c-a4e7-14a14365ca0a',29,NULL,NULL,NULL,'<p>This is the about us page.</p>'),(94,1064,'16264fe8-6a1a-42c7-82f1-b9362fa90572',28,NULL,NULL,'Products',NULL),(95,1064,'16264fe8-6a1a-42c7-82f1-b9362fa90572',29,NULL,NULL,NULL,'<p>Products Page List</p>'),(96,1064,'b9c4b5d1-3c5f-4758-85c8-e7e2fdf33deb',28,NULL,NULL,'Products',NULL),(97,1064,'b9c4b5d1-3c5f-4758-85c8-e7e2fdf33deb',29,NULL,NULL,NULL,'<p>Products Page List</p>'),(98,1064,'193b8a2f-bb95-4470-ab9f-9a9bd5a6211a',28,NULL,NULL,'Products',NULL),(99,1064,'193b8a2f-bb95-4470-ab9f-9a9bd5a6211a',29,NULL,NULL,NULL,'<p>Products Page List 234567</p>'),(100,1064,'8cd13135-c716-4c0a-8ced-f8aba7bb31f2',28,NULL,NULL,'Products',NULL),(101,1064,'8cd13135-c716-4c0a-8ced-f8aba7bb31f2',29,NULL,NULL,NULL,'<p>Products Page List 234567</p>'),(102,1064,'f9c10a21-668d-4005-8ebf-9e8eb1ee40f3',28,NULL,NULL,'Products',NULL),(103,1064,'f9c10a21-668d-4005-8ebf-9e8eb1ee40f3',29,NULL,NULL,NULL,'<p>Products Page List 234567</p>'),(104,1062,'3520c8d1-eee7-4add-aaeb-00041ca2174d',28,NULL,NULL,'About us',NULL),(105,1062,'3520c8d1-eee7-4add-aaeb-00041ca2174d',29,NULL,NULL,NULL,'<p>This is the about us page.</p>'),(106,1066,'35c447d8-9fa1-4aa8-afe7-e97908a3583c',28,NULL,NULL,'Our Business',NULL),(107,1066,'35c447d8-9fa1-4aa8-afe7-e97908a3583c',29,NULL,NULL,NULL,'<p>Our Business page</p>'),(108,1074,'0c1ad280-68b8-4b93-9cf2-9332681c3815',31,NULL,NULL,'',NULL),(109,1074,'0c1ad280-68b8-4b93-9cf2-9332681c3815',32,NULL,NULL,NULL,''),(110,1074,'c41b4ce8-433d-4290-838a-ee12a0cb893d',31,NULL,NULL,'',NULL),(111,1074,'c41b4ce8-433d-4290-838a-ee12a0cb893d',32,NULL,NULL,NULL,''),(112,1074,'adaa7989-762c-4224-899f-5840a448b16c',31,NULL,NULL,'',NULL),(113,1074,'adaa7989-762c-4224-899f-5840a448b16c',32,NULL,NULL,NULL,''),(114,1074,'03fc47df-df58-4aed-8a42-593dba5a8467',31,NULL,NULL,'',NULL),(115,1074,'03fc47df-df58-4aed-8a42-593dba5a8467',32,NULL,NULL,NULL,''),(116,1074,'fa728a68-36f8-4fad-a738-5e3d19eba52c',31,NULL,NULL,'Upload, Share, Vote ...',NULL),(117,1074,'fa728a68-36f8-4fad-a738-5e3d19eba52c',32,NULL,NULL,NULL,''),(118,1074,'5a1a174c-6f84-4c93-b7af-4f33f08e01c5',31,NULL,NULL,'Upload, Share, Vote ...',NULL),(119,1074,'5a1a174c-6f84-4c93-b7af-4f33f08e01c5',32,NULL,NULL,NULL,''),(120,1074,'53a99c2e-3113-402a-a98a-384ebb035723',31,NULL,NULL,'Upload, Share, Vote ...',NULL),(121,1074,'53a99c2e-3113-402a-a98a-384ebb035723',32,NULL,NULL,NULL,''),(122,1074,'a18add03-8c1e-4b62-b8ac-67e828b92c5f',31,NULL,NULL,'Upload, Share, Vote ...',NULL),(123,1074,'a18add03-8c1e-4b62-b8ac-67e828b92c5f',32,NULL,NULL,NULL,''),(124,1074,'5ad27bbc-16df-4560-97e0-23a71aeb7c3c',31,NULL,NULL,'Upload, Share, Vote ...',NULL),(125,1074,'5ad27bbc-16df-4560-97e0-23a71aeb7c3c',32,NULL,NULL,NULL,''),(126,1074,'cf8a3123-00ca-4ac3-b418-d0d6489de38f',31,NULL,NULL,'Upload, Share, Vote ...',NULL),(127,1074,'cf8a3123-00ca-4ac3-b418-d0d6489de38f',32,NULL,NULL,NULL,''),(128,1075,'c6be571b-800e-4265-80c9-609484a48fb9',6,NULL,NULL,'/media/1009/aboutNew.png',NULL),(129,1075,'c6be571b-800e-4265-80c9-609484a48fb9',7,NULL,NULL,'16',NULL),(130,1075,'c6be571b-800e-4265-80c9-609484a48fb9',8,NULL,NULL,'16',NULL),(131,1075,'c6be571b-800e-4265-80c9-609484a48fb9',9,NULL,NULL,'1178',NULL),(132,1075,'c6be571b-800e-4265-80c9-609484a48fb9',10,NULL,NULL,'png',NULL),(139,1078,'4a82a0e2-7897-4eaf-95e3-d0d5fb4dda1f',34,NULL,NULL,'/media/1013/audit.png',NULL),(140,1078,'4a82a0e2-7897-4eaf-95e3-d0d5fb4dda1f',35,NULL,NULL,'16',NULL),(141,1078,'4a82a0e2-7897-4eaf-95e3-d0d5fb4dda1f',36,NULL,NULL,'16',NULL),(142,1078,'4a82a0e2-7897-4eaf-95e3-d0d5fb4dda1f',37,NULL,NULL,'897',NULL),(143,1078,'4a82a0e2-7897-4eaf-95e3-d0d5fb4dda1f',38,NULL,NULL,'png',NULL),(144,1078,'4a82a0e2-7897-4eaf-95e3-d0d5fb4dda1f',33,NULL,NULL,'qwe',NULL),(145,1074,'f4a2ec82-d7a3-45ca-9731-00be1fdc0ec4',31,NULL,NULL,'Upload, Share, Vote ...',NULL),(146,1074,'f4a2ec82-d7a3-45ca-9731-00be1fdc0ec4',32,NULL,NULL,NULL,'<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />'),(147,1074,'9926b88d-d804-44da-97ad-5a95784d8ca2',31,NULL,NULL,'Upload, Share, Vote ...',NULL),(148,1074,'9926b88d-d804-44da-97ad-5a95784d8ca2',32,NULL,NULL,NULL,'<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />'),(149,1074,'fa18e13e-6198-4f8c-999c-b8d2a9431063',31,NULL,NULL,'Upload, Share, Vote ...',NULL),(150,1074,'fa18e13e-6198-4f8c-999c-b8d2a9431063',32,NULL,NULL,NULL,'<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />'),(151,1074,'eb8b6d64-cbec-49ee-b695-7d1de111ca04',31,NULL,NULL,'Upload, Share, Vote ...',NULL),(152,1074,'eb8b6d64-cbec-49ee-b695-7d1de111ca04',32,NULL,NULL,NULL,'<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />'),(153,1079,'51af98a7-75d8-4733-acbe-e9abf1ec09e2',34,NULL,NULL,'/media/1014/developer.png',NULL),(154,1079,'51af98a7-75d8-4733-acbe-e9abf1ec09e2',35,NULL,NULL,'256',NULL),(155,1079,'51af98a7-75d8-4733-acbe-e9abf1ec09e2',36,NULL,NULL,'256',NULL),(156,1079,'51af98a7-75d8-4733-acbe-e9abf1ec09e2',37,NULL,NULL,'19431',NULL),(157,1079,'51af98a7-75d8-4733-acbe-e9abf1ec09e2',38,NULL,NULL,'png',NULL),(158,1079,'51af98a7-75d8-4733-acbe-e9abf1ec09e2',33,NULL,NULL,'Wow! The developer png...',NULL),(159,1074,'30ebdca7-b9f5-4447-ac7c-0d2e6a769f22',31,NULL,NULL,'Upload, Share, Vote ...',NULL),(160,1074,'30ebdca7-b9f5-4447-ac7c-0d2e6a769f22',32,NULL,NULL,NULL,'<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />'),(161,1074,'4dc571a4-7358-4fa1-a674-78bfde232e80',31,NULL,NULL,'Upload, Share, Vote ...',NULL),(162,1074,'4dc571a4-7358-4fa1-a674-78bfde232e80',32,NULL,NULL,NULL,'<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />'),(163,1080,'f9c01d28-228c-4455-a66b-032ebc8adbe2',34,NULL,NULL,'/media/1015/folder.png',NULL),(164,1080,'f9c01d28-228c-4455-a66b-032ebc8adbe2',35,NULL,NULL,'256',NULL),(165,1080,'f9c01d28-228c-4455-a66b-032ebc8adbe2',36,NULL,NULL,'256',NULL),(166,1080,'f9c01d28-228c-4455-a66b-032ebc8adbe2',37,NULL,NULL,'21034',NULL),(167,1080,'f9c01d28-228c-4455-a66b-032ebc8adbe2',38,NULL,NULL,'png',NULL),(168,1080,'f9c01d28-228c-4455-a66b-032ebc8adbe2',33,NULL,NULL,'Another nice image',NULL),(169,1081,'519575e5-68b3-42f5-ba73-a1fa736c1176',34,NULL,NULL,'/media/1016/xml.png',NULL),(170,1081,'519575e5-68b3-42f5-ba73-a1fa736c1176',35,NULL,NULL,'256',NULL),(171,1081,'519575e5-68b3-42f5-ba73-a1fa736c1176',36,NULL,NULL,'256',NULL),(172,1081,'519575e5-68b3-42f5-ba73-a1fa736c1176',37,NULL,NULL,'12153',NULL),(173,1081,'519575e5-68b3-42f5-ba73-a1fa736c1176',38,NULL,NULL,'png',NULL),(174,1081,'519575e5-68b3-42f5-ba73-a1fa736c1176',33,NULL,NULL,'Xml is beautiful',NULL),(175,1082,'bd69e48b-ab13-4c0b-bd5f-7a7ffefafb8b',31,NULL,NULL,'',NULL),(176,1082,'bd69e48b-ab13-4c0b-bd5f-7a7ffefafb8b',32,NULL,NULL,NULL,''),(177,1082,'2d029673-3d4c-40ab-99cc-c302607f786d',31,NULL,NULL,'',NULL),(178,1082,'2d029673-3d4c-40ab-99cc-c302607f786d',32,NULL,NULL,NULL,''),(179,1082,'c9caf9ec-39d9-40f6-ba9b-be9510c621bc',31,NULL,NULL,'The originals',NULL),(180,1082,'c9caf9ec-39d9-40f6-ba9b-be9510c621bc',32,NULL,NULL,NULL,''),(181,1082,'3af08dc3-85d6-4b5c-b21e-7b5e01ae962c',31,NULL,NULL,'The originals',NULL),(182,1082,'3af08dc3-85d6-4b5c-b21e-7b5e01ae962c',32,NULL,NULL,NULL,''),(183,1082,'b6fb195d-f1cc-4af9-a454-933236852aea',31,NULL,NULL,'The originals',NULL),(184,1082,'b6fb195d-f1cc-4af9-a454-933236852aea',32,NULL,NULL,NULL,'<h2>We were serving long before the others...</h2>\r\n<p>Etc., etc.</p>'),(185,1082,'d36dc3d8-4348-4588-b953-a9cc6cb80f37',31,NULL,NULL,'The originals',NULL),(186,1082,'d36dc3d8-4348-4588-b953-a9cc6cb80f37',32,NULL,NULL,NULL,'<h2>We were serving long before the others...</h2>\r\n<p>Etc., etc.</p>'),(187,1082,'7d2aefa6-99a8-4f47-ac08-939adf7a83eb',31,NULL,NULL,'The originals',NULL),(188,1082,'7d2aefa6-99a8-4f47-ac08-939adf7a83eb',32,NULL,NULL,NULL,'<h2>We were serving long before the others...</h2>\r\n<p>Etc., etc.</p>'),(189,1082,'2d43400e-8bb5-4318-b54e-c87247898ab5',31,NULL,NULL,'The originals',NULL),(190,1082,'2d43400e-8bb5-4318-b54e-c87247898ab5',32,NULL,NULL,NULL,'<h2>We were serving long before the others...</h2>\r\n<p>Etc., etc.</p>');
/*!40000 ALTER TABLE `cmspropertydata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsstylesheet`
--

DROP TABLE IF EXISTS `cmsstylesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsstylesheet` (
  `nodeId` int(11) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `content` longtext,
  PRIMARY KEY (`nodeId`),
  CONSTRAINT `cmsstylesheet_ibfk_1` FOREIGN KEY (`nodeId`) REFERENCES `umbraconode` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsstylesheet`
--

LOCK TABLES `cmsstylesheet` WRITE;
/*!40000 ALTER TABLE `cmsstylesheet` DISABLE KEYS */;
INSERT INTO `cmsstylesheet` VALUES (1056,'','.testClass {\n	font-size: 16px;	\n	}');
/*!40000 ALTER TABLE `cmsstylesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umbracouser`
--

DROP TABLE IF EXISTS `umbracouser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbracouser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userDisabled` tinyint(1) NOT NULL DEFAULT '0',
  `userNoConsole` tinyint(1) NOT NULL DEFAULT '0',
  `userType` int(11) NOT NULL,
  `startStructureID` int(11) NOT NULL,
  `startMediaID` int(11) DEFAULT NULL,
  `userName` varchar(255) NOT NULL,
  `userLogin` varchar(125) NOT NULL,
  `userPassword` varchar(125) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `userDefaultPermissions` varchar(50) DEFAULT NULL,
  `userLanguage` varchar(10) DEFAULT NULL,
  `defaultToLiveEditing` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userType` (`userType`),
  KEY `IX_umbracoUser_userLogin` (`userLogin`),
  CONSTRAINT `umbracouser_ibfk_1` FOREIGN KEY (`userType`) REFERENCES `umbracousertype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umbracouser`
--

LOCK TABLES `umbracouser` WRITE;
/*!40000 ALTER TABLE `umbracouser` DISABLE KEYS */;
INSERT INTO `umbracouser` VALUES (0,0,0,1,-1,-1,'admin','admin','kW+7AlKMnSZQIRluNxwJOMiohAw=','admin@domain.com',NULL,'en',0),(1,0,0,6,-1,-1,'TestUser','TestUser','W477AMlLwwJQeAGlPZKiEILr8TA=','',NULL,'en',0),(2,0,0,4,-1,-1,'TestTranslator','testt',']rja)#F','',NULL,'en',0);
/*!40000 ALTER TABLE `umbracouser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmstags`
--

DROP TABLE IF EXISTS `cmstags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmstags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(200) DEFAULT NULL,
  `ParentId` int(11) DEFAULT NULL,
  `group` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmstags`
--

LOCK TABLES `cmstags` WRITE;
/*!40000 ALTER TABLE `cmstags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmstags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsmacro`
--

DROP TABLE IF EXISTS `cmsmacro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsmacro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `macroUseInEditor` tinyint(1) NOT NULL DEFAULT '0',
  `macroRefreshRate` int(11) NOT NULL DEFAULT '0',
  `macroAlias` varchar(255) NOT NULL,
  `macroName` varchar(255) DEFAULT NULL,
  `macroScriptType` varchar(255) DEFAULT NULL,
  `macroScriptAssembly` varchar(255) DEFAULT NULL,
  `macroXSLT` varchar(255) DEFAULT NULL,
  `macroCacheByPage` tinyint(1) NOT NULL DEFAULT '1',
  `macroCachePersonalized` tinyint(1) NOT NULL DEFAULT '0',
  `macroDontRender` tinyint(1) NOT NULL DEFAULT '0',
  `macroPython` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsmacro`
--

LOCK TABLES `cmsmacro` WRITE;
/*!40000 ALTER TABLE `cmsmacro` DISABLE KEYS */;
INSERT INTO `cmsmacro` VALUES (1,0,0,'TestMacro','TestMacro','','','',1,0,0,''),(2,0,0,'TestBreadcrumb','Test Breadcrumb',NULL,NULL,NULL,1,0,0,'TestBreadcrumb.cshtml'),(3,0,0,'TestXslt','Test Xslt',NULL,NULL,'TestXslt.xslt',1,0,0,NULL),(4,0,0,'TestPartialViewMacro','Test Partial View Macro',NULL,NULL,NULL,1,0,0,'~/Views/MacroPartials/TestPartialViewMacro.cshtml'),(5,1,0,'ImageGalleryMacro','Image Gallery Macro','','','',1,0,1,'~/Views/MacroPartials/ImageGalleryMacro.cshtml');
/*!40000 ALTER TABLE `cmsmacro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmscontenttypeallowedcontenttype`
--

DROP TABLE IF EXISTS `cmscontenttypeallowedcontenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmscontenttypeallowedcontenttype` (
  `Id` int(11) NOT NULL,
  `AllowedId` int(11) NOT NULL,
  `SortOrder` int(11) NOT NULL DEFAULT '0',
  KEY `Id` (`Id`),
  KEY `AllowedId` (`AllowedId`),
  CONSTRAINT `cmscontenttypeallowedcontenttype_ibfk_1` FOREIGN KEY (`Id`) REFERENCES `cmscontenttype` (`nodeId`),
  CONSTRAINT `cmscontenttypeallowedcontenttype_ibfk_2` FOREIGN KEY (`AllowedId`) REFERENCES `cmscontenttype` (`nodeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmscontenttypeallowedcontenttype`
--

LOCK TABLES `cmscontenttypeallowedcontenttype` WRITE;
/*!40000 ALTER TABLE `cmscontenttypeallowedcontenttype` DISABLE KEYS */;
INSERT INTO `cmscontenttypeallowedcontenttype` VALUES (1031,1033,0),(1031,1031,1),(1031,1032,2),(1058,1058,0),(1072,1072,0);
/*!40000 ALTER TABLE `cmscontenttypeallowedcontenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmspropertytype`
--

DROP TABLE IF EXISTS `cmspropertytype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmspropertytype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dataTypeId` int(11) NOT NULL,
  `contentTypeId` int(11) NOT NULL,
  `propertyTypeGroupId` int(11) DEFAULT NULL,
  `Alias` varchar(255) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `helpText` varchar(1000) DEFAULT NULL,
  `sortOrder` int(11) NOT NULL DEFAULT '0',
  `mandatory` tinyint(1) NOT NULL DEFAULT '0',
  `validationRegExp` varchar(255) DEFAULT NULL,
  `Description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dataTypeId` (`dataTypeId`),
  KEY `contentTypeId` (`contentTypeId`),
  KEY `propertyTypeGroupId` (`propertyTypeGroupId`),
  CONSTRAINT `cmspropertytype_ibfk_1` FOREIGN KEY (`dataTypeId`) REFERENCES `cmsdatatype` (`nodeId`),
  CONSTRAINT `cmspropertytype_ibfk_2` FOREIGN KEY (`contentTypeId`) REFERENCES `cmscontenttype` (`nodeId`),
  CONSTRAINT `cmspropertytype_ibfk_3` FOREIGN KEY (`propertyTypeGroupId`) REFERENCES `cmspropertytypegroup` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmspropertytype`
--

LOCK TABLES `cmspropertytype` WRITE;
/*!40000 ALTER TABLE `cmspropertytype` DISABLE KEYS */;
INSERT INTO `cmspropertytype` VALUES (6,-90,1032,3,'umbracoFile','Upload image',NULL,0,0,NULL,NULL),(7,-92,1032,3,'umbracoWidth','Width',NULL,0,0,NULL,NULL),(8,-92,1032,3,'umbracoHeight','Height',NULL,0,0,NULL,NULL),(9,-92,1032,3,'umbracoBytes','Size',NULL,0,0,NULL,NULL),(10,-92,1032,3,'umbracoExtension','Type',NULL,0,0,NULL,NULL),(24,-90,1033,4,'umbracoFile','Upload file',NULL,0,0,NULL,NULL),(25,-92,1033,4,'umbracoExtension','Type',NULL,0,0,NULL,NULL),(26,-92,1033,4,'umbracoBytes','Size',NULL,0,0,NULL,NULL),(27,-38,1031,5,'contents','Contents:',NULL,0,0,'',''),(28,-88,1058,6,'title','Title',NULL,0,0,'',''),(29,-87,1058,6,'bodyContent','Body Content',NULL,0,0,'',''),(30,-88,1060,7,'testProperty','TestProperty',NULL,0,0,'',''),(31,-88,1070,8,'pageTitle','Page Title',NULL,0,0,'',''),(32,-87,1072,9,'bodyText','Body Text',NULL,0,0,'',''),(33,-88,1076,10,'comments','Comments',NULL,0,0,'',''),(34,-90,1076,NULL,'umbracoFile','Upload Image',NULL,0,0,'',''),(35,-92,1076,NULL,'umbracoWidth','Width',NULL,0,0,'',''),(36,-92,1076,NULL,'umbracoHeight','Height',NULL,0,0,'',''),(37,-92,1076,NULL,'umbracoBytes','Size',NULL,0,0,'',''),(38,-92,1076,NULL,'umbracoExtension','Type',NULL,0,0,'','');
/*!40000 ALTER TABLE `cmspropertytype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umbracousertype`
--

DROP TABLE IF EXISTS `umbracousertype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbracousertype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userTypeAlias` varchar(50) DEFAULT NULL,
  `userTypeName` varchar(255) NOT NULL,
  `userTypeDefaultPermissions` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umbracousertype`
--

LOCK TABLES `umbracousertype` WRITE;
/*!40000 ALTER TABLE `umbracousertype` DISABLE KEYS */;
INSERT INTO `umbracousertype` VALUES (1,'admin','Administrators','CADMOSKTPIURZ:5F'),(2,'writer','Writer','CAH:F'),(3,'editor','Editors','CADMOSKTPUZ:5F'),(4,'translator','Translator','AF'),(6,'TestUserType','TestUserType','');
/*!40000 ALTER TABLE `umbracousertype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umbraconode`
--

DROP TABLE IF EXISTS `umbraconode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbraconode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trashed` tinyint(1) NOT NULL DEFAULT '0',
  `parentID` int(11) NOT NULL,
  `nodeUser` int(11) DEFAULT NULL,
  `level` int(11) NOT NULL,
  `path` varchar(150) NOT NULL,
  `sortOrder` int(11) NOT NULL,
  `uniqueID` char(36) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `nodeObjectType` char(36) DEFAULT NULL,
  `createDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IX_umbracoNodeParentId` (`parentID`),
  KEY `IX_umbracoNodeObjectType` (`nodeObjectType`),
  CONSTRAINT `umbraconode_ibfk_1` FOREIGN KEY (`parentID`) REFERENCES `umbraconode` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1083 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umbraconode`
--

LOCK TABLES `umbraconode` WRITE;
/*!40000 ALTER TABLE `umbraconode` DISABLE KEYS */;
INSERT INTO `umbraconode` VALUES (-92,0,-1,0,1,'-1,-92',35,'f0bc4bfb-b499-40d6-ba86-058885a5178c','Label','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-90,0,-1,0,1,'-1,-90',34,'84c6b441-31df-4ffe-b67e-67d5bc3ae65a','Upload','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-89,0,-1,0,1,'-1,-89',33,'c6bac0dd-4ab9-45b1-8e30-e4b619ee5da3','Textbox multiple','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-88,0,-1,0,1,'-1,-88',32,'0cc0eba1-9960-42c9-bf9b-60e150b429ae','Textstring','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-87,0,-1,0,1,'-1,-87',4,'ca90c950-0aff-4e72-b976-a30b1ac57dad','Richtext editor','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-51,0,-1,0,1,'-1,-51',2,'2e6d3631-066e-44b8-aec4-96f09099b2b5','Numeric','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-49,0,-1,0,1,'-1,-49',2,'92897bc6-a5f3-4ffe-ae27-f2e7e33dda49','True/false','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-43,0,-1,0,1,'-1,-43',2,'fbaf13a8-4036-41f2-93a3-974f678c312a','Checkbox list','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-42,0,-1,0,1,'-1,-42',2,'0b6a45e7-44ba-430d-9da5-4e46060b9e03','Dropdown','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-41,0,-1,0,1,'-1,-41',2,'5046194e-4237-453c-a547-15db3a07c4e1','Date Picker','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-40,0,-1,0,1,'-1,-40',2,'bb5f57c9-ce2b-4bb9-b697-4caca783a805','Radiobox','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-39,0,-1,0,1,'-1,-39',2,'f38f0ac7-1d27-439c-9f3f-089cd8825a53','Dropdown multiple','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-38,0,-1,0,1,'-1,-38',2,'fd9f1447-6c61-4a7c-9595-5aa39147d318','Folder Browser','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-37,0,-1,0,1,'-1,-37',2,'0225af17-b302-49cb-9176-b9f35cab9c17','Approved Color','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-36,0,-1,0,1,'-1,-36',2,'e4d66c0f-b935-4200-81f0-025f7256b89a','Date Picker with time','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(-21,0,-1,0,0,'-1,-21',0,'bf7c7cbc-952f-4518-97a2-69e9c7b33842','Recycle Bin','cf3d8e34-1c1c-41e9-ae56-878b57b32113','2013-04-28 11:24:34'),(-20,0,-1,0,0,'-1,-20',0,'0f582a79-1e41-4cf0-bfa0-76340651891a','Recycle Bin','01bb7ff2-24dc-4c0c-95a2-c24ef72bbac8','2013-04-28 11:24:34'),(-1,0,-1,0,0,'-1',0,'916724a5-173d-4619-b97e-b9de133dd6f5','SYSTEM DATA: umbraco master root','ea7d8624-4cfe-4578-a871-24aa946bf34d','2013-04-28 11:24:34'),(1031,0,-1,0,1,'-1,1031',2,'f38bd2d7-65d0-48e6-95dc-87ce06ec2d3d','Folder','4ea4382b-2f5a-4c2b-9587-ae9b3cf3602e','2013-04-28 11:24:34'),(1032,0,-1,0,1,'-1,1032',2,'cc07b313-0843-4aa8-bbda-871c8da728c8','Image','4ea4382b-2f5a-4c2b-9587-ae9b3cf3602e','2013-04-28 11:24:34'),(1033,0,-1,0,1,'-1,1033',2,'4c52d8ab-54e6-40cd-999c-7a5f24903e4d','File','4ea4382b-2f5a-4c2b-9587-ae9b3cf3602e','2013-04-28 11:24:34'),(1034,0,-1,0,1,'-1,1034',2,'a6857c73-d6e9-480c-b6e6-f15f6ad11125','Content Picker','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(1035,0,-1,0,1,'-1,1035',2,'93929b9a-93a2-4e2a-b239-d99334440a59','Media Picker','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(1036,0,-1,0,1,'-1,1036',2,'2b24165f-9782-4aa3-b459-1de4a4d21f60','Member Picker','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(1038,0,-1,0,1,'-1,1038',2,'1251c96c-185c-4e9b-93f4-b48205573cbd','Simple Editor','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(1039,0,-1,0,1,'-1,1039',2,'06f349a9-c949-4b6a-8660-59c10451af42','Ultimate Picker','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(1040,0,-1,0,1,'-1,1040',2,'21e798da-e06e-4eda-a511-ed257f78d4fa','Related Links','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(1041,0,-1,0,1,'-1,1041',2,'b6b73142-b9c1-4bf8-a16d-e1c23320b549','Tags','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(1042,0,-1,0,1,'-1,1042',2,'0a452bd5-83f9-4bc3-8403-1286e13fb77e','Macro Container','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(1043,0,-1,0,1,'-1,1043',2,'1df9f033-e6d4-451f-b8d2-e0cbc50a836f','Image Cropper','30a2a501-1978-4ddb-a57b-f7efed43ba3c','2013-04-28 11:24:34'),(1045,0,-1,0,1,'-1,1045',0,'f412b150-bb3c-4839-a40f-846c85bff563','TestFolder','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-05-05 10:00:15'),(1046,0,1045,0,2,'-1,1045,1046',0,'8ef1a18e-4eee-4426-bd7f-a4b9c0ddf111','TestFile','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-05-05 11:29:53'),(1047,0,1045,0,2,'-1,1045,1047',1,'67c0254a-dc06-4ef1-a4bd-8ce80fb933fb','TestImage','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-05-05 11:30:12'),(1048,0,1045,0,2,'-1,1045,1048',2,'7e8a6246-af64-4fd2-9b9f-8a34b71cc539','TestFolder2','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-05-05 11:30:34'),(1049,0,1048,0,3,'-1,1045,1048,1049',0,'6bade5b8-fe19-48eb-9d59-89b0c5d84197','Arrowdown','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-05-05 11:48:23'),(1050,0,1048,0,3,'-1,1045,1048,1050',1,'d606ff9a-d023-478d-983a-2341fbd43ef6','Arrowforward','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-05-05 11:48:23'),(1051,0,1048,0,3,'-1,1045,1048,1051',2,'29aa4120-bb7a-473f-beb6-fe866a03fd06','Audit','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-05-05 11:48:23'),(1052,0,1048,0,3,'-1,1045,1048,1052',3,'9af935f1-b928-4c8e-bee7-f583b29797f2','Back','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-05-05 11:48:24'),(1053,0,-1,0,1,'-1,1053',0,'23da1fd9-4448-4e3d-9eb1-59f8f9b27ad7','testType','9b5416fb-e72f-45a9-a07b-5a9a2709ce43','2013-05-05 12:23:46'),(1054,0,-1,0,1,'-1,1054',0,'82f54fe1-7c22-4597-b5c0-d1bd360b64d5','TestMemberGroup','366e63b9-880f-4e13-a61c-98069b029728','2013-05-06 07:31:40'),(1055,0,-1,0,1,'-1,1055',0,'58e14cb2-50ea-4efd-a25f-f90bb66c99bb','TestMember','39eb0f98-b348-42a1-8662-e7eb18487560','2013-05-06 07:37:45'),(1056,0,-1,0,1,'-1,1056',0,'436d7ae1-dfe7-4d86-b59a-0e19efd1f23d','TestCss','9f68da4f-a3a8-44c2-8226-dcbd125e4840','2013-05-06 08:38:17'),(1057,0,-1,0,1,'-1,1057',0,'3ac18ce6-3156-42b1-a30a-233597151b50','TestTemplate','6fbde604-4178-42ce-a10b-8a2600a2f07d','2013-05-06 09:25:53'),(1058,0,-1,0,1,'-1,1058',0,'47588810-aecb-4940-9257-47476c271e86','TestDocumentType','a2cb7800-f571-4787-9638-bc48539a0efb','2013-05-06 09:34:33'),(1059,0,-1,0,1,'-1,1059',0,'21204b84-ff3a-4907-aada-bf5acf39535b','TestDocumentType','6fbde604-4178-42ce-a10b-8a2600a2f07d','2013-05-06 09:34:33'),(1060,0,-1,0,1,'-1,1060',3,'4600acec-9026-48a4-8145-200b420f5bf3','TestMediaType','4ea4382b-2f5a-4c2b-9587-ae9b3cf3602e','2013-05-06 11:01:45'),(1061,0,-1,0,1,'-1,1061',1,'a967e26e-df18-4f63-b6b6-5f312c1ef55b','HomePage','c66ba18e-eaf3-4cff-8a22-41b16d66a972','2013-05-06 17:01:40'),(1062,0,1061,0,2,'-1,1061,1062',1,'6f40becb-47b4-4e8c-a497-366a1bff9f98','About us','c66ba18e-eaf3-4cff-8a22-41b16d66a972','2013-05-06 17:15:50'),(1063,0,1061,0,2,'-1,1061,1063',0,'2ba755d8-aa61-4e52-ab7b-9e3348a8fbcc','Contact Us','c66ba18e-eaf3-4cff-8a22-41b16d66a972','2013-05-06 17:19:26'),(1064,0,1061,0,2,'-1,1061,1064',2,'074950b2-dd8d-4455-9bc0-d40b708d1df1','Products','c66ba18e-eaf3-4cff-8a22-41b16d66a972','2013-05-06 17:20:02'),(1066,0,1062,0,3,'-1,1061,1062,1066',1,'6e41b70e-50f8-4a2a-8069-50007f4b38bd','Our Business','c66ba18e-eaf3-4cff-8a22-41b16d66a972','2013-05-06 17:22:20'),(1067,0,1063,0,3,'-1,1061,1063,1067',0,'9766596d-c6bf-4fd3-b9c4-e8101749e3e8','Our Business','c66ba18e-eaf3-4cff-8a22-41b16d66a972','2013-05-06 17:26:48'),(1070,0,-1,0,1,'-1,1070',2,'6f78e456-5ed5-4360-a82d-7acfa764dd37','PageBase','a2cb7800-f571-4787-9638-bc48539a0efb','2013-06-10 20:12:13'),(1071,0,-1,0,1,'-1,1071',1,'feaf6d3c-ea2e-4778-aaa8-9df257932628','PageBase','6fbde604-4178-42ce-a10b-8a2600a2f07d','2013-06-10 20:12:13'),(1072,0,1070,0,2,'-1,1070,1072',6,'8e2ed93f-ffa8-41df-93e4-320f7ee55c0e','TextPage','a2cb7800-f571-4787-9638-bc48539a0efb','2013-06-10 20:12:53'),(1073,0,-1,0,1,'-1,1073',1,'aa121f11-8975-4a1e-9ade-19d8ef745630','TextPage','6fbde604-4178-42ce-a10b-8a2600a2f07d','2013-06-10 20:20:41'),(1074,0,-1,0,1,'-1,1074',0,'2797205f-28d5-463d-b142-67a21dd1e537','Home Page','c66ba18e-eaf3-4cff-8a22-41b16d66a972','2013-06-10 20:50:25'),(1075,1,-21,0,1,'-1,-21,1075',1,'559bc941-4145-44aa-9a66-2f45edf3491a','aboutNew.png','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-06-10 22:04:49'),(1076,0,-1,0,1,'-1,1076',4,'19ae7143-1a11-49dc-a251-f4285b432078','ImageWithComment','4ea4382b-2f5a-4c2b-9587-ae9b3cf3602e','2013-06-10 22:09:00'),(1078,1,-21,0,1,'-1,-21,1078',3,'8439efca-eaf3-436e-b27c-1af63920e004','audit.png','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-06-10 22:50:43'),(1079,0,-1,0,1,'-1,1079',3,'1bd2fdf9-8935-4823-b4b5-d3b288a39590','developer.png','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-06-10 23:36:43'),(1080,0,-1,0,1,'-1,1080',2,'eb9c3193-1976-4440-9490-785441fd205f','folder.png','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-06-10 23:44:15'),(1081,0,-1,0,1,'-1,1081',3,'67e0aee1-9354-435b-88ba-02f9a2602897','xml.png','b796f64c-1f99-4ffb-b886-4bf4bc011a9c','2013-06-10 23:44:34'),(1082,0,1074,0,2,'-1,1074,1082',0,'7fb8b8f7-2dff-4dff-9186-907753871501','About Us','c66ba18e-eaf3-4cff-8a22-41b16d66a972','2013-06-11 00:46:06');
/*!40000 ALTER TABLE `umbraconode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmscontentversion`
--

DROP TABLE IF EXISTS `cmscontentversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmscontentversion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ContentId` int(11) NOT NULL,
  `VersionId` char(36) NOT NULL,
  `VersionDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `LanguageLocale` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ContentId` (`ContentId`),
  KEY `IX_cmsContentVersion_VersionId` (`VersionId`),
  CONSTRAINT `cmscontentversion_ibfk_1` FOREIGN KEY (`ContentId`) REFERENCES `cmscontent` (`nodeId`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmscontentversion`
--

LOCK TABLES `cmscontentversion` WRITE;
/*!40000 ALTER TABLE `cmscontentversion` DISABLE KEYS */;
INSERT INTO `cmscontentversion` VALUES (2,1045,'c5f79643-2946-481f-977e-a13ae76e2781','2013-05-05 10:00:15',NULL),(3,1046,'f3d1d3d1-a0d2-43f1-b139-ba25ca3a2b88','2013-05-05 11:29:53',NULL),(4,1047,'a8f55890-b9fb-4960-8cb2-d9751e9e32d9','2013-05-05 11:30:12',NULL),(5,1048,'01a99380-cbeb-4812-a542-a50ac8b97793','2013-05-05 11:30:34',NULL),(6,1049,'65f94eff-9085-4072-96b3-18bae92f9507','2013-05-05 11:48:23',NULL),(7,1050,'223b5063-bfd2-43df-8415-a52bfa3ce4d0','2013-05-05 11:48:23',NULL),(8,1051,'e2de6479-00ff-4800-9f50-d13ad6cb6aba','2013-05-05 11:48:23',NULL),(9,1052,'322a3efd-369b-4c57-869b-13f501238ce7','2013-05-05 11:48:24',NULL),(10,1055,'10264818-880f-43ca-b41f-645679d21915','2013-05-06 07:37:45',NULL),(11,1061,'c7db23da-ab44-49e7-84d5-c231ac9e44d6','2013-05-06 17:05:03',NULL),(12,1061,'5d9ea0d1-dedc-4b7a-aa3d-a3bffd0e92bf','2013-05-06 17:05:03',NULL),(13,1061,'a60121ff-c9fe-4943-af9e-405c3921e911','2013-05-06 17:05:33',NULL),(14,1061,'60833a6b-0a5d-4ccc-9dfd-213e979dbe7d','2013-05-06 17:05:33',NULL),(15,1061,'56f2c2d1-9ac9-4b80-bfe7-25c9b5da2ba3','2013-05-06 17:07:52',NULL),(16,1061,'88a2ee4e-151f-42cb-9813-3260764d726a','2013-05-06 17:07:52',NULL),(17,1061,'46640e05-3bae-47f7-aa3d-ac9f3e5a1d8e','2013-05-06 17:12:12',NULL),(18,1061,'781abae0-2b45-4688-bffe-c86c3042b76a','2013-05-06 17:12:13',NULL),(19,1061,'821e4fb6-a6f5-417e-a407-2de56b7c28fb','2013-05-06 17:12:34',NULL),(20,1061,'18c2505e-84e7-401a-884d-298eb1a4507e','2013-05-06 17:12:35',NULL),(21,1061,'dc5f75e6-2ddb-4bcf-8758-463db624e4d7','2013-05-06 17:13:04',NULL),(22,1061,'7bf4385c-7b56-44eb-9005-9507745bcf58','2013-06-10 20:50:42',NULL),(23,1062,'5790c3f9-2e45-4515-90b9-3159806b903d','2013-05-06 17:18:02',NULL),(24,1062,'8c96354b-8823-4645-8e74-9d926640bb91','2013-05-06 17:18:02',NULL),(25,1062,'fff8f575-7681-4e14-9352-79e880e66ad3','2013-05-06 17:18:24',NULL),(26,1062,'54a32d32-f50e-4adf-965c-1a772772295a','2013-05-06 17:18:24',NULL),(27,1063,'c8f3842a-c66d-4930-9ace-6825f8b35581','2013-05-06 17:19:41',NULL),(28,1063,'9d99984a-4155-4fd4-9fe4-554eab6b6c9e','2013-05-06 17:19:41',NULL),(29,1064,'14ae6a88-02ff-47b2-9157-d16b657ea5f8','2013-05-06 17:20:23',NULL),(30,1064,'2efd1b7c-3c27-44bd-bb2a-0d0369832d35','2013-05-06 17:20:24',NULL),(33,1066,'1bb58018-edb1-4fcf-a4c8-b32356183262','2013-05-06 17:22:34',NULL),(34,1066,'1495b5f7-8c2a-42e1-9f46-55cf6089d7d7','2013-05-06 17:22:34',NULL),(35,1066,'3eeb8f28-afe7-41d3-b36f-684f4d66ee1c','2013-05-06 17:25:52',NULL),(36,1067,'2374f9d1-f242-4fae-a57e-fae68dc55b80','2013-05-06 17:27:31',NULL),(37,1067,'4927a34d-9d43-4d0f-8c8d-a3a226f42404','2013-05-06 17:27:31',NULL),(38,1063,'1900974f-075b-4d69-8e7f-a2ce06956b83','2013-05-06 17:35:29',NULL),(39,1063,'65affbce-3499-46f2-9172-d4fd4e2be979','2013-05-06 17:35:29',NULL),(40,1062,'42de697d-2d07-411e-841f-8e897e0e90d0','2013-05-06 17:35:30',NULL),(41,1062,'88727743-7961-479c-a4e7-14a14365ca0a','2013-05-06 17:35:30',NULL),(42,1064,'16264fe8-6a1a-42c7-82f1-b9362fa90572','2013-05-06 17:37:59',NULL),(43,1064,'b9c4b5d1-3c5f-4758-85c8-e7e2fdf33deb','2013-05-06 17:35:30',NULL),(44,1064,'193b8a2f-bb95-4470-ab9f-9a9bd5a6211a','2013-05-06 17:35:47',NULL),(45,1064,'8cd13135-c716-4c0a-8ced-f8aba7bb31f2','2013-05-06 17:35:47',NULL),(46,1064,'f9c10a21-668d-4005-8ebf-9e8eb1ee40f3','2013-05-06 17:40:58',NULL),(47,1062,'3520c8d1-eee7-4add-aaeb-00041ca2174d','2013-05-06 17:41:15',NULL),(48,1066,'35c447d8-9fa1-4aa8-afe7-e97908a3583c','2013-05-06 17:41:15',NULL),(49,1074,'0c1ad280-68b8-4b93-9cf2-9332681c3815','2013-06-10 20:50:31',NULL),(50,1074,'c41b4ce8-433d-4290-838a-ee12a0cb893d','2013-06-10 20:50:31',NULL),(51,1074,'adaa7989-762c-4224-899f-5840a448b16c','2013-06-10 20:50:42',NULL),(52,1074,'03fc47df-df58-4aed-8a42-593dba5a8467','2013-06-10 20:50:42',NULL),(53,1074,'fa728a68-36f8-4fad-a738-5e3d19eba52c','2013-06-10 20:51:45',NULL),(54,1074,'5a1a174c-6f84-4c93-b7af-4f33f08e01c5','2013-06-10 20:51:45',NULL),(55,1074,'53a99c2e-3113-402a-a98a-384ebb035723','2013-06-10 20:53:29',NULL),(56,1074,'a18add03-8c1e-4b62-b8ac-67e828b92c5f','2013-06-10 20:53:29',NULL),(57,1074,'5ad27bbc-16df-4560-97e0-23a71aeb7c3c','2013-06-10 20:53:43',NULL),(58,1074,'cf8a3123-00ca-4ac3-b418-d0d6489de38f','2013-06-10 20:53:43',NULL),(59,1075,'c6be571b-800e-4265-80c9-609484a48fb9','2013-06-10 22:04:49',NULL),(61,1078,'4a82a0e2-7897-4eaf-95e3-d0d5fb4dda1f','2013-06-10 22:50:43',NULL),(62,1074,'f4a2ec82-d7a3-45ca-9731-00be1fdc0ec4','2013-06-10 22:55:30',NULL),(63,1074,'9926b88d-d804-44da-97ad-5a95784d8ca2','2013-06-10 22:55:30',NULL),(64,1074,'fa18e13e-6198-4f8c-999c-b8d2a9431063','2013-06-10 22:55:44',NULL),(65,1074,'eb8b6d64-cbec-49ee-b695-7d1de111ca04','2013-06-10 22:55:45',NULL),(66,1079,'51af98a7-75d8-4733-acbe-e9abf1ec09e2','2013-06-10 23:36:43',NULL),(67,1074,'30ebdca7-b9f5-4447-ac7c-0d2e6a769f22','2013-06-10 23:38:22',NULL),(68,1074,'4dc571a4-7358-4fa1-a674-78bfde232e80','2013-06-10 23:38:22',NULL),(69,1080,'f9c01d28-228c-4455-a66b-032ebc8adbe2','2013-06-10 23:44:15',NULL),(70,1081,'519575e5-68b3-42f5-ba73-a1fa736c1176','2013-06-10 23:44:34',NULL),(71,1082,'bd69e48b-ab13-4c0b-bd5f-7a7ffefafb8b','2013-06-11 00:46:11',NULL),(72,1082,'2d029673-3d4c-40ab-99cc-c302607f786d','2013-06-11 00:46:11',NULL),(73,1082,'c9caf9ec-39d9-40f6-ba9b-be9510c621bc','2013-06-11 00:46:19',NULL),(74,1082,'3af08dc3-85d6-4b5c-b21e-7b5e01ae962c','2013-06-11 00:46:19',NULL),(75,1082,'b6fb195d-f1cc-4af9-a454-933236852aea','2013-06-11 00:47:05',NULL),(76,1082,'d36dc3d8-4348-4588-b953-a9cc6cb80f37','2013-06-11 00:47:05',NULL),(77,1082,'7d2aefa6-99a8-4f47-ac08-939adf7a83eb','2013-06-11 00:49:14',NULL),(78,1082,'2d43400e-8bb5-4318-b54e-c87247898ab5','2013-06-11 00:49:14',NULL);
/*!40000 ALTER TABLE `cmscontentversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsmacroproperty`
--

DROP TABLE IF EXISTS `cmsmacroproperty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsmacroproperty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `macroPropertyHidden` tinyint(1) NOT NULL DEFAULT '0',
  `macroPropertyType` int(11) NOT NULL,
  `macro` int(11) NOT NULL,
  `macroPropertySortOrder` int(11) NOT NULL DEFAULT '0',
  `macroPropertyAlias` varchar(50) NOT NULL,
  `macroPropertyName` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `macroPropertyType` (`macroPropertyType`),
  KEY `macro` (`macro`),
  CONSTRAINT `cmsmacroproperty_ibfk_1` FOREIGN KEY (`macroPropertyType`) REFERENCES `cmsmacropropertytype` (`id`),
  CONSTRAINT `cmsmacroproperty_ibfk_2` FOREIGN KEY (`macro`) REFERENCES `cmsmacro` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsmacroproperty`
--

LOCK TABLES `cmsmacroproperty` WRITE;
/*!40000 ALTER TABLE `cmsmacroproperty` DISABLE KEYS */;
INSERT INTO `cmsmacroproperty` VALUES (1,1,16,1,0,'Test Parameter','TestParameters');
/*!40000 ALTER TABLE `cmsmacroproperty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umbracouserlogins`
--

DROP TABLE IF EXISTS `umbracouserlogins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbracouserlogins` (
  `contextID` char(36) NOT NULL,
  `userID` int(11) NOT NULL,
  `timeout` bigint(20) NOT NULL,
  KEY `umbracoUserLogins_Index` (`contextID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umbracouserlogins`
--

LOCK TABLES `umbracouserlogins` WRITE;
/*!40000 ALTER TABLE `umbracouserlogins` DISABLE KEYS */;
INSERT INTO `umbracouserlogins` VALUES ('e286ccf6-d2ea-40d2-840b-3b10b47c4576',0,635027831773121510),('eac0f9c0-d577-4797-9deb-9dfbc7862fe6',0,635034332512076950),('ce834b95-7b0a-4796-9f56-a5825140e0fc',0,635034643331895550),('d9eb615c-3f70-4a69-8c8f-aa9fe8e3ae16',0,635063161834966760),('c3f1f501-e3cd-4554-ba7b-01bdf751b42f',1,635062877421649540),('528f9531-648d-4997-a318-e448e435ef28',0,635065142885730800);
/*!40000 ALTER TABLE `umbracouserlogins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmstemplate`
--

DROP TABLE IF EXISTS `cmstemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmstemplate` (
  `pk` int(11) NOT NULL AUTO_INCREMENT,
  `nodeId` int(11) NOT NULL,
  `master` int(11) DEFAULT NULL,
  `alias` varchar(100) DEFAULT NULL,
  `design` longtext NOT NULL,
  PRIMARY KEY (`pk`),
  KEY `master` (`master`),
  KEY `IX_cmsTemplate_nodeId` (`nodeId`),
  CONSTRAINT `cmstemplate_ibfk_1` FOREIGN KEY (`nodeId`) REFERENCES `umbraconode` (`id`),
  CONSTRAINT `cmstemplate_ibfk_2` FOREIGN KEY (`master`) REFERENCES `umbraconode` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmstemplate`
--

LOCK TABLES `cmstemplate` WRITE;
/*!40000 ALTER TABLE `cmstemplate` DISABLE KEYS */;
INSERT INTO `cmstemplate` VALUES (1,1057,NULL,'TestTemplate','@inherits Umbraco.Web.Mvc.UmbracoTemplatePage\n@{\n    Layout = null;\n}\nTestMvcView'),(2,1059,NULL,'TestDocumentType','@inherits Umbraco.Web.Mvc.UmbracoTemplatePage\n@{\n    Layout = null;\n}\n<html>\n	<head>\n	<title>@Umbraco.Field(\"pageName\")</title>\n	</head>\n	<body>\n	@Umbraco.RenderMacro(\"TestPartialViewMacro\")\n	<h2>@Umbraco.Field(\"title\")</h2>\n	<hr />\n	<div>@Umbraco.Field(\"bodyContent\")</div>\n	</body>\n</html>'),(4,1071,NULL,'PageBase','@inherits Umbraco.Web.Mvc.UmbracoTemplatePage\n@{\n    Layout = null;\n}\n\n<html>\n<head>\n	<title>The Galleria - @Umbraco.Field(\"pageName\")</title>\n</head>\n<body>\n	@RenderSection(\"Common\", false)\n	@RenderBody()\n</body>	\n</html>'),(5,1073,1071,'TextPage','@inherits Umbraco.Web.Mvc.UmbracoTemplatePage\n@{\n    Layout = \"PageBase.cshtml\";\n}\n\n@section Common\n{\n	@Umbraco.Field(\"pageTitle\")\n}\n\n@Umbraco.Field(\"bodyText\")\n	\n<hr />\n<div>\n@{Html.RenderAction<ImageSurfaceController>(\"RenderForm\");}\n</div>	\n<hr />');
/*!40000 ALTER TABLE `cmstemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsmembertype`
--

DROP TABLE IF EXISTS `cmsmembertype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsmembertype` (
  `pk` int(11) NOT NULL AUTO_INCREMENT,
  `NodeId` int(11) NOT NULL,
  `propertytypeId` int(11) NOT NULL,
  `memberCanEdit` tinyint(1) NOT NULL DEFAULT '0',
  `viewOnProfile` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pk`),
  KEY `NodeId` (`NodeId`),
  CONSTRAINT `cmsmembertype_ibfk_1` FOREIGN KEY (`NodeId`) REFERENCES `cmscontenttype` (`nodeId`),
  CONSTRAINT `cmsmembertype_ibfk_2` FOREIGN KEY (`NodeId`) REFERENCES `umbraconode` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsmembertype`
--

LOCK TABLES `cmsmembertype` WRITE;
/*!40000 ALTER TABLE `cmsmembertype` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmsmembertype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umbracorelation`
--

DROP TABLE IF EXISTS `umbracorelation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbracorelation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) NOT NULL,
  `childId` int(11) NOT NULL,
  `relType` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comment` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parentId` (`parentId`),
  KEY `childId` (`childId`),
  KEY `relType` (`relType`),
  CONSTRAINT `umbracorelation_ibfk_1` FOREIGN KEY (`parentId`) REFERENCES `umbraconode` (`id`),
  CONSTRAINT `umbracorelation_ibfk_2` FOREIGN KEY (`childId`) REFERENCES `umbraconode` (`id`),
  CONSTRAINT `umbracorelation_ibfk_3` FOREIGN KEY (`relType`) REFERENCES `umbracorelationtype` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umbracorelation`
--

LOCK TABLES `umbracorelation` WRITE;
/*!40000 ALTER TABLE `umbracorelation` DISABLE KEYS */;
/*!40000 ALTER TABLE `umbracorelation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmstasktype`
--

DROP TABLE IF EXISTS `cmstasktype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmstasktype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_cmsTaskType_alias` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmstasktype`
--

LOCK TABLES `cmstasktype` WRITE;
/*!40000 ALTER TABLE `cmstasktype` DISABLE KEYS */;
INSERT INTO `cmstasktype` VALUES (1,'toTranslate');
/*!40000 ALTER TABLE `cmstasktype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmscontenttype`
--

DROP TABLE IF EXISTS `cmscontenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmscontenttype` (
  `pk` int(11) NOT NULL AUTO_INCREMENT,
  `nodeId` int(11) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `thumbnail` varchar(255) NOT NULL DEFAULT 'folder.png',
  `description` varchar(1500) DEFAULT NULL,
  `isContainer` tinyint(1) NOT NULL DEFAULT '0',
  `allowAtRoot` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pk`),
  KEY `IX_cmsContentType` (`nodeId`),
  KEY `IX_cmsContentType_icon` (`icon`),
  CONSTRAINT `cmscontenttype_ibfk_1` FOREIGN KEY (`nodeId`) REFERENCES `umbraconode` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=542 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmscontenttype`
--

LOCK TABLES `cmscontenttype` WRITE;
/*!40000 ALTER TABLE `cmscontenttype` DISABLE KEYS */;
INSERT INTO `cmscontenttype` VALUES (532,1031,'Folder','folder.gif','folder.png','',1,1),(533,1032,'Image','mediaPhoto.gif','mediaPhoto.png',NULL,0,0),(534,1033,'File','mediaFile.gif','mediaFile.png',NULL,0,0),(535,1053,'testType','member.gif','folder.png','',0,0),(536,1058,'TestDocumentType','doc2.gif','doc.png','',0,1),(537,1060,'TestMediaType','folder.gif','folder.png','',0,1),(539,1070,'PageBase','doc3.gif','docWithImage.png','',0,0),(540,1072,'TextPage','doc3.gif','docWithImage.png','',0,1),(541,1076,'ImageWithComment','mediaFile.gif','mediaPhoto.png','',0,0);
/*!40000 ALTER TABLE `cmscontenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsdatatypeprevalues`
--

DROP TABLE IF EXISTS `cmsdatatypeprevalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsdatatypeprevalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datatypeNodeId` int(11) NOT NULL,
  `value` varchar(2500) DEFAULT NULL,
  `sortorder` int(11) NOT NULL,
  `alias` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `datatypeNodeId` (`datatypeNodeId`),
  CONSTRAINT `cmsdatatypeprevalues_ibfk_1` FOREIGN KEY (`datatypeNodeId`) REFERENCES `cmsdatatype` (`nodeId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsdatatypeprevalues`
--

LOCK TABLES `cmsdatatypeprevalues` WRITE;
/*!40000 ALTER TABLE `cmsdatatypeprevalues` DISABLE KEYS */;
INSERT INTO `cmsdatatypeprevalues` VALUES (3,-87,',code,undo,redo,cut,copy,mcepasteword,stylepicker,bold,italic,bullist,numlist,outdent,indent,mcelink,unlink,mceinsertanchor,mceimage,umbracomacro,mceinserttable,umbracoembed,mcecharmap,|1|1,2,3,|0|500,400|1049,|true|',0,''),(4,1041,'default',0,'group');
/*!40000 ALTER TABLE `cmsdatatypeprevalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmslanguagetext`
--

DROP TABLE IF EXISTS `cmslanguagetext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmslanguagetext` (
  `pk` int(11) NOT NULL AUTO_INCREMENT,
  `languageId` int(11) NOT NULL,
  `UniqueId` char(36) NOT NULL,
  `value` varchar(1000) NOT NULL,
  PRIMARY KEY (`pk`),
  KEY `UniqueId` (`UniqueId`),
  CONSTRAINT `cmslanguagetext_ibfk_1` FOREIGN KEY (`UniqueId`) REFERENCES `cmsdictionary` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmslanguagetext`
--

LOCK TABLES `cmslanguagetext` WRITE;
/*!40000 ALTER TABLE `cmslanguagetext` DISABLE KEYS */;
INSERT INTO `cmslanguagetext` VALUES (1,0,'7b20ab5a-55ad-4079-b924-ac5f688afe48',''),(2,1,'7b20ab5a-55ad-4079-b924-ac5f688afe48','TEST WORD'),(3,2,'7b20ab5a-55ad-4079-b924-ac5f688afe48','Ye olde test');
/*!40000 ALTER TABLE `cmslanguagetext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umbracouser2nodepermission`
--

DROP TABLE IF EXISTS `umbracouser2nodepermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbracouser2nodepermission` (
  `userId` int(11) NOT NULL,
  `nodeId` int(11) NOT NULL,
  `permission` varchar(255) NOT NULL,
  KEY `userId` (`userId`),
  KEY `nodeId` (`nodeId`),
  CONSTRAINT `umbracouser2nodepermission_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `umbracouser` (`id`),
  CONSTRAINT `umbracouser2nodepermission_ibfk_2` FOREIGN KEY (`nodeId`) REFERENCES `umbraconode` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umbracouser2nodepermission`
--

LOCK TABLES `umbracouser2nodepermission` WRITE;
/*!40000 ALTER TABLE `umbracouser2nodepermission` DISABLE KEYS */;
INSERT INTO `umbracouser2nodepermission` VALUES (1,1061,'F'),(1,1063,'F'),(1,1067,'F'),(1,1062,'F'),(1,1066,'F'),(1,1064,'F'),(1,1061,'O'),(1,1063,'O'),(1,1067,'O'),(1,1062,'O'),(1,1066,'O'),(1,1064,'O'),(1,1061,'M'),(1,1063,'M'),(1,1067,'M'),(1,1062,'M'),(1,1066,'M'),(1,1064,'M'),(1,1061,'C'),(1,1063,'C'),(1,1067,'C'),(1,1062,'C'),(1,1066,'C'),(1,1064,'C'),(1,1061,'A'),(1,1063,'A'),(1,1067,'A'),(1,1062,'A'),(1,1066,'A'),(1,1064,'A');
/*!40000 ALTER TABLE `umbracouser2nodepermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umbracorelationtype`
--

DROP TABLE IF EXISTS `umbracorelationtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbracorelationtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dual` tinyint(1) NOT NULL,
  `parentObjectType` char(36) NOT NULL,
  `childObjectType` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `alias` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umbracorelationtype`
--

LOCK TABLES `umbracorelationtype` WRITE;
/*!40000 ALTER TABLE `umbracorelationtype` DISABLE KEYS */;
INSERT INTO `umbracorelationtype` VALUES (1,1,'c66ba18e-eaf3-4cff-8a22-41b16d66a972','c66ba18e-eaf3-4cff-8a22-41b16d66a972','Relate Document On Copy','relateDocumentOnCopy');
/*!40000 ALTER TABLE `umbracorelationtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmscontenttype2contenttype`
--

DROP TABLE IF EXISTS `cmscontenttype2contenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmscontenttype2contenttype` (
  `parentContentTypeId` int(11) NOT NULL,
  `childContentTypeId` int(11) NOT NULL,
  KEY `parentContentTypeId` (`parentContentTypeId`),
  KEY `childContentTypeId` (`childContentTypeId`),
  CONSTRAINT `cmscontenttype2contenttype_ibfk_1` FOREIGN KEY (`parentContentTypeId`) REFERENCES `umbraconode` (`id`),
  CONSTRAINT `cmscontenttype2contenttype_ibfk_2` FOREIGN KEY (`childContentTypeId`) REFERENCES `umbraconode` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmscontenttype2contenttype`
--

LOCK TABLES `cmscontenttype2contenttype` WRITE;
/*!40000 ALTER TABLE `cmscontenttype2contenttype` DISABLE KEYS */;
INSERT INTO `cmscontenttype2contenttype` VALUES (1070,1072);
/*!40000 ALTER TABLE `cmscontenttype2contenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmscontentxml`
--

DROP TABLE IF EXISTS `cmscontentxml`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmscontentxml` (
  `nodeId` int(11) NOT NULL,
  `xml` longtext NOT NULL,
  PRIMARY KEY (`nodeId`),
  CONSTRAINT `cmscontentxml_ibfk_1` FOREIGN KEY (`nodeId`) REFERENCES `cmscontent` (`nodeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmscontentxml`
--

LOCK TABLES `cmscontentxml` WRITE;
/*!40000 ALTER TABLE `cmscontentxml` DISABLE KEYS */;
INSERT INTO `cmscontentxml` VALUES (1045,'<Folder id=\"1045\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-05T11:00:15\" updateDate=\"2013-05-05T11:00:15\" nodeName=\"TestFolder\" urlName=\"testfolder\" path=\"-1,1045\" isDoc=\"\" nodeType=\"1031\" writerName=\"admin\" writerID=\"0\" version=\"c5f79643-2946-481f-977e-a13ae76e2781\" template=\"0\">\r\n  <contents xmlns=\"\"></contents>\r\n</Folder>'),(1046,'<File id=\"1046\" version=\"f3d1d3d1-a0d2-43f1-b139-ba25ca3a2b88\" parentID=\"1045\" level=\"2\" writerID=\"0\" nodeType=\"1033\" template=\"0\" sortOrder=\"0\" createDate=\"2013-05-05T12:29:53\" updateDate=\"2013-05-05T12:46:08\" nodeName=\"TestFile\" urlName=\"testfile\" writerName=\"admin\" nodeTypeAlias=\"File\" path=\"-1,1045,1046\"><umbracoFile>/media/1003/2.txt</umbracoFile><umbracoExtension>txt</umbracoExtension><umbracoBytes>8482</umbracoBytes></File>'),(1047,'<Image id=\"1047\" version=\"a8f55890-b9fb-4960-8cb2-d9751e9e32d9\" parentID=\"1045\" level=\"2\" writerID=\"0\" nodeType=\"1032\" template=\"0\" sortOrder=\"1\" createDate=\"2013-05-05T12:30:12\" updateDate=\"2013-05-05T12:46:54\" nodeName=\"TestImage\" urlName=\"testimage\" writerName=\"admin\" nodeTypeAlias=\"Image\" path=\"-1,1045,1047\"><umbracoFile>/media/1004/aboutnew.png</umbracoFile><umbracoWidth>16</umbracoWidth><umbracoHeight>16</umbracoHeight><umbracoBytes>1178</umbracoBytes><umbracoExtension>png</umbracoExtension></Image>'),(1048,'<Folder id=\"1048\" parentID=\"1045\" level=\"2\" creatorID=\"0\" sortOrder=\"2\" createDate=\"2013-05-05T12:30:34\" updateDate=\"2013-05-05T12:30:34\" nodeName=\"TestFolder2\" urlName=\"testfolder2\" path=\"-1,1045,1048\" isDoc=\"\" nodeType=\"1031\" writerName=\"admin\" writerID=\"0\" version=\"01a99380-cbeb-4812-a542-a50ac8b97793\" template=\"0\">\r\n  <contents xmlns=\"\"></contents>\r\n</Folder>'),(1049,'<Image id=\"1049\" version=\"65f94eff-9085-4072-96b3-18bae92f9507\" parentID=\"1048\" level=\"3\" writerID=\"0\" nodeType=\"1032\" template=\"0\" sortOrder=\"0\" createDate=\"2013-05-05T12:48:23\" updateDate=\"2013-05-05T12:48:23\" nodeName=\"Arrowdown\" urlName=\"arrowdown\" writerName=\"admin\" nodeTypeAlias=\"Image\" path=\"-1,1045,1048,1049\"><umbracoFile>/media/1005/arrowDown.gif</umbracoFile><umbracoWidth>20</umbracoWidth><umbracoHeight>7</umbracoHeight><umbracoBytes>832</umbracoBytes><umbracoExtension>gif</umbracoExtension></Image>'),(1050,'<Image id=\"1050\" version=\"223b5063-bfd2-43df-8415-a52bfa3ce4d0\" parentID=\"1048\" level=\"3\" writerID=\"0\" nodeType=\"1032\" template=\"0\" sortOrder=\"1\" createDate=\"2013-05-05T12:48:23\" updateDate=\"2013-05-05T12:48:23\" nodeName=\"Arrowforward\" urlName=\"arrowforward\" writerName=\"admin\" nodeTypeAlias=\"Image\" path=\"-1,1045,1048,1050\"><umbracoFile>/media/1006/arrowForward.gif</umbracoFile><umbracoWidth>7</umbracoWidth><umbracoHeight>20</umbracoHeight><umbracoBytes>834</umbracoBytes><umbracoExtension>gif</umbracoExtension></Image>'),(1051,'<Image id=\"1051\" version=\"e2de6479-00ff-4800-9f50-d13ad6cb6aba\" parentID=\"1048\" level=\"3\" writerID=\"0\" nodeType=\"1032\" template=\"0\" sortOrder=\"2\" createDate=\"2013-05-05T12:48:23\" updateDate=\"2013-05-05T12:48:24\" nodeName=\"Audit\" urlName=\"audit\" writerName=\"admin\" nodeTypeAlias=\"Image\" path=\"-1,1045,1048,1051\"><umbracoFile>/media/1007/audit.png</umbracoFile><umbracoWidth>16</umbracoWidth><umbracoHeight>16</umbracoHeight><umbracoBytes>897</umbracoBytes><umbracoExtension>png</umbracoExtension></Image>'),(1052,'<Image id=\"1052\" version=\"322a3efd-369b-4c57-869b-13f501238ce7\" parentID=\"1048\" level=\"3\" writerID=\"0\" nodeType=\"1032\" template=\"0\" sortOrder=\"3\" createDate=\"2013-05-05T12:48:24\" updateDate=\"2013-05-05T12:48:24\" nodeName=\"Back\" urlName=\"back\" writerName=\"admin\" nodeTypeAlias=\"Image\" path=\"-1,1045,1048,1052\"><umbracoFile>/media/1008/back.png</umbracoFile><umbracoWidth>16</umbracoWidth><umbracoHeight>16</umbracoHeight><umbracoBytes>422</umbracoBytes><umbracoExtension>png</umbracoExtension></Image>'),(1055,'<node id=\"1055\" version=\"10264818-880f-43ca-b41f-645679d21915\" parentID=\"-1\" level=\"1\" writerID=\"0\" nodeType=\"1053\" template=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T08:37:45\" updateDate=\"2013-05-06T08:37:45\" nodeName=\"TestMember\" urlName=\"testmember\" writerName=\"admin\" nodeTypeAlias=\"testType\" path=\"-1,1055\" loginName=\"test\" email=\"test@test.com\" />'),(1062,'<TestDocumentType id=\"1062\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-05-06T18:15:50\" updateDate=\"2013-05-06T18:41:15\" nodeName=\"About us\" urlName=\"about-us\" path=\"-1,1061,1062\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">About us</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>This is the about us page.</p>]]></bodyContent>\r\n</TestDocumentType>'),(1063,'<TestDocumentType id=\"1063\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:19:26\" updateDate=\"2013-05-06T18:35:29\" nodeName=\"Contact Us\" urlName=\"contact-us\" path=\"-1,1061,1063\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\"><title xmlns=\"\">Contact Us</title><bodyContent xmlns=\"\"><![CDATA[<p>Contact Us page</p>]]></bodyContent></TestDocumentType>'),(1064,'<TestDocumentType id=\"1064\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"2\" createDate=\"2013-05-06T18:20:02\" updateDate=\"2013-05-06T18:40:58\" nodeName=\"Products\" urlName=\"products\" path=\"-1,1061,1064\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Products</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Products Page List 234567</p>]]></bodyContent>\r\n</TestDocumentType>'),(1066,'<TestDocumentType id=\"1066\" parentID=\"1062\" level=\"3\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-05-06T18:22:20\" updateDate=\"2013-05-06T18:41:15\" nodeName=\"Our Business\" urlName=\"our-business\" path=\"-1,1061,1062,1066\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Our Business</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Our Business page</p>]]></bodyContent>\r\n</TestDocumentType>'),(1067,'<TestDocumentType id=\"1067\" parentID=\"1063\" level=\"3\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:26:48\" updateDate=\"2013-05-06T18:27:31\" nodeName=\"Our Business\" urlName=\"our-business\" path=\"-1,1061,1063,1067\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Our Head Office</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Head office page</p>]]></bodyContent>\r\n</TestDocumentType>'),(1074,'<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-11T00:38:22\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />]]></bodyText>\r\n</TextPage>'),(1075,'<Image id=\"1075\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-06-10T23:04:49\" updateDate=\"2013-06-10T23:04:49\" nodeName=\"aboutNew.png\" urlName=\"aboutnewpng\" path=\"-1,1075\" isDoc=\"\" nodeType=\"1032\" writerName=\"admin\" writerID=\"0\" version=\"c6be571b-800e-4265-80c9-609484a48fb9\" template=\"0\">\r\n  <umbracoFile xmlns=\"\">/media/1009/aboutNew.png</umbracoFile>\r\n  <umbracoWidth xmlns=\"\">16</umbracoWidth>\r\n  <umbracoHeight xmlns=\"\">16</umbracoHeight>\r\n  <umbracoBytes xmlns=\"\">1178</umbracoBytes>\r\n  <umbracoExtension xmlns=\"\">png</umbracoExtension>\r\n</Image>'),(1078,'<ImageWithComment id=\"1078\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"2\" createDate=\"2013-06-10T23:50:43\" updateDate=\"2013-06-10T23:50:43\" nodeName=\"audit.png\" urlName=\"auditpng\" path=\"-1,1078\" isDoc=\"\" nodeType=\"1076\" writerName=\"admin\" writerID=\"0\" version=\"4a82a0e2-7897-4eaf-95e3-d0d5fb4dda1f\" template=\"0\">\r\n  <umbracoFile xmlns=\"\">/media/1013/audit.png</umbracoFile>\r\n  <umbracoWidth xmlns=\"\">16</umbracoWidth>\r\n  <umbracoHeight xmlns=\"\">16</umbracoHeight>\r\n  <umbracoBytes xmlns=\"\">897</umbracoBytes>\r\n  <umbracoExtension xmlns=\"\">png</umbracoExtension>\r\n  <comments xmlns=\"\">qwe</comments>\r\n</ImageWithComment>'),(1079,'<ImageWithComment id=\"1079\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"3\" createDate=\"2013-06-11T00:36:43\" updateDate=\"2013-06-11T00:36:43\" nodeName=\"developer.png\" urlName=\"developerpng\" path=\"-1,1079\" isDoc=\"\" nodeType=\"1076\" writerName=\"admin\" writerID=\"0\" version=\"51af98a7-75d8-4733-acbe-e9abf1ec09e2\" template=\"0\">\r\n  <umbracoFile xmlns=\"\">/media/1014/developer.png</umbracoFile>\r\n  <umbracoWidth xmlns=\"\">256</umbracoWidth>\r\n  <umbracoHeight xmlns=\"\">256</umbracoHeight>\r\n  <umbracoBytes xmlns=\"\">19431</umbracoBytes>\r\n  <umbracoExtension xmlns=\"\">png</umbracoExtension>\r\n  <comments xmlns=\"\">Wow! The developer png...</comments>\r\n</ImageWithComment>'),(1080,'<ImageWithComment id=\"1080\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"2\" createDate=\"2013-06-11T00:44:15\" updateDate=\"2013-06-11T00:44:15\" nodeName=\"folder.png\" urlName=\"folderpng\" path=\"-1,1080\" isDoc=\"\" nodeType=\"1076\" writerName=\"admin\" writerID=\"0\" version=\"f9c01d28-228c-4455-a66b-032ebc8adbe2\" template=\"0\">\r\n  <umbracoFile xmlns=\"\">/media/1015/folder.png</umbracoFile>\r\n  <umbracoWidth xmlns=\"\">256</umbracoWidth>\r\n  <umbracoHeight xmlns=\"\">256</umbracoHeight>\r\n  <umbracoBytes xmlns=\"\">21034</umbracoBytes>\r\n  <umbracoExtension xmlns=\"\">png</umbracoExtension>\r\n  <comments xmlns=\"\">Another nice image</comments>\r\n</ImageWithComment>'),(1081,'<ImageWithComment id=\"1081\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"3\" createDate=\"2013-06-11T00:44:34\" updateDate=\"2013-06-11T00:44:34\" nodeName=\"xml.png\" urlName=\"xmlpng\" path=\"-1,1081\" isDoc=\"\" nodeType=\"1076\" writerName=\"admin\" writerID=\"0\" version=\"519575e5-68b3-42f5-ba73-a1fa736c1176\" template=\"0\">\r\n  <umbracoFile xmlns=\"\">/media/1016/xml.png</umbracoFile>\r\n  <umbracoWidth xmlns=\"\">256</umbracoWidth>\r\n  <umbracoHeight xmlns=\"\">256</umbracoHeight>\r\n  <umbracoBytes xmlns=\"\">12153</umbracoBytes>\r\n  <umbracoExtension xmlns=\"\">png</umbracoExtension>\r\n  <comments xmlns=\"\">Xml is beautiful</comments>\r\n</ImageWithComment>'),(1082,'<TextPage id=\"1082\" parentID=\"1074\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-11T01:46:06\" updateDate=\"2013-06-11T01:49:14\" nodeName=\"About Us\" urlName=\"about-us\" path=\"-1,1074,1082\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">The originals</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[<h2>We were serving long before the others...</h2>\r\n<p>Etc., etc.</p>]]></bodyText>\r\n</TextPage>');
/*!40000 ALTER TABLE `cmscontentxml` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsdictionary`
--

DROP TABLE IF EXISTS `cmsdictionary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsdictionary` (
  `pk` int(11) NOT NULL AUTO_INCREMENT,
  `id` char(36) NOT NULL,
  `parent` char(36) NOT NULL,
  `key` varchar(1000) NOT NULL,
  PRIMARY KEY (`pk`),
  KEY `IX_cmsDictionary_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsdictionary`
--

LOCK TABLES `cmsdictionary` WRITE;
/*!40000 ALTER TABLE `cmsdictionary` DISABLE KEYS */;
INSERT INTO `cmsdictionary` VALUES (1,'7b20ab5a-55ad-4079-b924-ac5f688afe48','41c7638d-f529-4bff-853e-59a0c2fb1bde','TestWord');
/*!40000 ALTER TABLE `cmsdictionary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsmember2membergroup`
--

DROP TABLE IF EXISTS `cmsmember2membergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsmember2membergroup` (
  `Member` int(11) NOT NULL,
  `MemberGroup` int(11) NOT NULL,
  KEY `Member` (`Member`),
  KEY `MemberGroup` (`MemberGroup`),
  CONSTRAINT `cmsmember2membergroup_ibfk_1` FOREIGN KEY (`Member`) REFERENCES `cmsmember` (`nodeId`),
  CONSTRAINT `cmsmember2membergroup_ibfk_2` FOREIGN KEY (`MemberGroup`) REFERENCES `umbraconode` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsmember2membergroup`
--

LOCK TABLES `cmsmember2membergroup` WRITE;
/*!40000 ALTER TABLE `cmsmember2membergroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmsmember2membergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmspropertytypegroup`
--

DROP TABLE IF EXISTS `cmspropertytypegroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmspropertytypegroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentGroupId` int(11) DEFAULT NULL,
  `contenttypeNodeId` int(11) NOT NULL,
  `text` varchar(255) NOT NULL,
  `sortorder` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parentGroupId` (`parentGroupId`),
  KEY `contenttypeNodeId` (`contenttypeNodeId`),
  CONSTRAINT `cmspropertytypegroup_ibfk_1` FOREIGN KEY (`parentGroupId`) REFERENCES `cmspropertytypegroup` (`id`),
  CONSTRAINT `cmspropertytypegroup_ibfk_2` FOREIGN KEY (`contenttypeNodeId`) REFERENCES `cmscontenttype` (`nodeId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmspropertytypegroup`
--

LOCK TABLES `cmspropertytypegroup` WRITE;
/*!40000 ALTER TABLE `cmspropertytypegroup` DISABLE KEYS */;
INSERT INTO `cmspropertytypegroup` VALUES (3,NULL,1032,'Image',1),(4,NULL,1033,'File',1),(5,NULL,1031,'Contents',1),(6,NULL,1058,'TestTab',0),(7,NULL,1060,'TestMediaTab',0),(8,NULL,1070,'Short Content',0),(9,NULL,1072,'Content',0),(10,NULL,1076,'Short Content',0);
/*!40000 ALTER TABLE `cmspropertytypegroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umbracolanguage`
--

DROP TABLE IF EXISTS `umbracolanguage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbracolanguage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `languageISOCode` varchar(10) DEFAULT NULL,
  `languageCultureName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_umbracoLanguage_languageISOCode` (`languageISOCode`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umbracolanguage`
--

LOCK TABLES `umbracolanguage` WRITE;
/*!40000 ALTER TABLE `umbracolanguage` DISABLE KEYS */;
INSERT INTO `umbracolanguage` VALUES (1,'en-US','en-US'),(2,'en-GB',NULL);
/*!40000 ALTER TABLE `umbracolanguage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsmacropropertytype`
--

DROP TABLE IF EXISTS `cmsmacropropertytype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsmacropropertytype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `macroPropertyTypeAlias` varchar(50) DEFAULT NULL,
  `macroPropertyTypeRenderAssembly` varchar(255) DEFAULT NULL,
  `macroPropertyTypeRenderType` varchar(255) DEFAULT NULL,
  `macroPropertyTypeBaseType` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsmacropropertytype`
--

LOCK TABLES `cmsmacropropertytype` WRITE;
/*!40000 ALTER TABLE `cmsmacropropertytype` DISABLE KEYS */;
INSERT INTO `cmsmacropropertytype` VALUES (3,'mediaCurrent','umbraco.macroRenderings','media','Int32'),(4,'contentSubs','umbraco.macroRenderings','content','Int32'),(5,'contentRandom','umbraco.macroRenderings','content','Int32'),(6,'contentPicker','umbraco.macroRenderings','content','Int32'),(13,'number','umbraco.macroRenderings','numeric','Int32'),(14,'bool','umbraco.macroRenderings','yesNo','Boolean'),(16,'text','umbraco.macroRenderings','text','String'),(17,'contentTree','umbraco.macroRenderings','content','Int32'),(18,'contentType','umbraco.macroRenderings','contentTypeSingle','Int32'),(19,'contentTypeMultiple','umbraco.macroRenderings','contentTypeMultiple','Int32'),(20,'contentAll','umbraco.macroRenderings','content','Int32'),(21,'tabPicker','umbraco.macroRenderings','tabPicker','String'),(22,'tabPickerMultiple','umbraco.macroRenderings','tabPickerMultiple','String'),(23,'propertyTypePicker','umbraco.macroRenderings','propertyTypePicker','String'),(24,'propertyTypePickerMultiple','umbraco.macroRenderings','propertyTypePickerMultiple','String'),(25,'textMultiLine','umbraco.macroRenderings','textMultiple','String');
/*!40000 ALTER TABLE `cmsmacropropertytype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmscontent`
--

DROP TABLE IF EXISTS `cmscontent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmscontent` (
  `pk` int(11) NOT NULL AUTO_INCREMENT,
  `nodeId` int(11) NOT NULL,
  `contentType` int(11) NOT NULL,
  PRIMARY KEY (`pk`),
  KEY `IX_cmsContent` (`nodeId`),
  CONSTRAINT `cmscontent_ibfk_1` FOREIGN KEY (`nodeId`) REFERENCES `umbraconode` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmscontent`
--

LOCK TABLES `cmscontent` WRITE;
/*!40000 ALTER TABLE `cmscontent` DISABLE KEYS */;
INSERT INTO `cmscontent` VALUES (2,1045,1031),(3,1046,1033),(4,1047,1032),(5,1048,1031),(6,1049,1032),(7,1050,1032),(8,1051,1032),(9,1052,1032),(10,1055,1053),(11,1061,1058),(12,1062,1058),(13,1063,1058),(14,1064,1058),(16,1066,1058),(17,1067,1058),(18,1074,1072),(19,1075,1032),(21,1078,1076),(22,1079,1076),(23,1080,1076),(24,1081,1076),(25,1082,1072);
/*!40000 ALTER TABLE `cmscontent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umbracouser2app`
--

DROP TABLE IF EXISTS `umbracouser2app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbracouser2app` (
  `user` int(11) NOT NULL,
  `app` varchar(50) NOT NULL,
  KEY `user` (`user`),
  CONSTRAINT `umbracouser2app_ibfk_1` FOREIGN KEY (`user`) REFERENCES `umbracouser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umbracouser2app`
--

LOCK TABLES `umbracouser2app` WRITE;
/*!40000 ALTER TABLE `umbracouser2app` DISABLE KEYS */;
INSERT INTO `umbracouser2app` VALUES (0,'content'),(0,'developer'),(0,'media'),(0,'member'),(0,'settings'),(0,'users'),(2,'content'),(1,'content'),(1,'media'),(1,'settings');
/*!40000 ALTER TABLE `umbracouser2app` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsstylesheetproperty`
--

DROP TABLE IF EXISTS `cmsstylesheetproperty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsstylesheetproperty` (
  `nodeId` int(11) NOT NULL,
  `stylesheetPropertyEditor` tinyint(1) DEFAULT NULL,
  `stylesheetPropertyAlias` varchar(50) DEFAULT NULL,
  `stylesheetPropertyValue` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`nodeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsstylesheetproperty`
--

LOCK TABLES `cmsstylesheetproperty` WRITE;
/*!40000 ALTER TABLE `cmsstylesheetproperty` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmsstylesheetproperty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umbracouser2nodenotify`
--

DROP TABLE IF EXISTS `umbracouser2nodenotify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbracouser2nodenotify` (
  `userId` int(11) NOT NULL,
  `nodeId` int(11) NOT NULL,
  `action` char(1) NOT NULL,
  KEY `userId` (`userId`),
  KEY `nodeId` (`nodeId`),
  CONSTRAINT `umbracouser2nodenotify_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `umbracouser` (`id`),
  CONSTRAINT `umbracouser2nodenotify_ibfk_2` FOREIGN KEY (`nodeId`) REFERENCES `umbraconode` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umbracouser2nodenotify`
--

LOCK TABLES `umbracouser2nodenotify` WRITE;
/*!40000 ALTER TABLE `umbracouser2nodenotify` DISABLE KEYS */;
/*!40000 ALTER TABLE `umbracouser2nodenotify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsdatatype`
--

DROP TABLE IF EXISTS `cmsdatatype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsdatatype` (
  `pk` int(11) NOT NULL AUTO_INCREMENT,
  `nodeId` int(11) NOT NULL,
  `controlId` char(36) NOT NULL,
  `dbType` varchar(50) NOT NULL,
  PRIMARY KEY (`pk`),
  KEY `IX_cmsDataType_nodeId` (`nodeId`),
  CONSTRAINT `cmsdatatype_ibfk_1` FOREIGN KEY (`nodeId`) REFERENCES `umbraconode` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsdatatype`
--

LOCK TABLES `cmsdatatype` WRITE;
/*!40000 ALTER TABLE `cmsdatatype` DISABLE KEYS */;
INSERT INTO `cmsdatatype` VALUES (1,-49,'38b352c1-e9f8-4fd8-9324-9a2eab06d97a','Integer'),(2,-51,'1413afcb-d19a-4173-8e9a-68288d2a73b8','Integer'),(3,-87,'5e9b75ae-face-41c8-b47e-5f4b0fd82f83','Ntext'),(4,-88,'ec15c1e5-9d90-422a-aa52-4f7622c63bea','Nvarchar'),(5,-89,'67db8357-ef57-493e-91ac-936d305e0f2a','Ntext'),(6,-90,'5032a6e6-69e3-491d-bb28-cd31cd11086c','Nvarchar'),(7,-92,'6c738306-4c17-4d88-b9bd-6546f3771597','Nvarchar'),(8,-36,'b6fb1622-afa5-4bbf-a3cc-d9672a442222','Date'),(9,-37,'f8d60f68-ec59-4974-b43b-c46eb5677985','Nvarchar'),(10,-38,'cccd4ae9-f399-4ed2-8038-2e88d19e810c','Nvarchar'),(11,-39,'928639ed-9c73-4028-920c-1e55dbb68783','Nvarchar'),(12,-40,'a52c7c1c-c330-476e-8605-d63d3b84b6a6','Nvarchar'),(13,-41,'23e93522-3200-44e2-9f29-e61a6fcbb79a','Date'),(14,-42,'a74ea9c9-8e18-4d2a-8cf6-73c6206c5da6','Integer'),(15,-43,'b4471851-82b6-4c75-afa4-39fa9c6a75e9','Nvarchar'),(16,1034,'158aa029-24ed-4948-939e-c3da209e5fba','Integer'),(17,1035,'ead69342-f06d-4253-83ac-28000225583b','Integer'),(18,1036,'39f533e4-0551-4505-a64b-e0425c5ce775','Integer'),(19,1038,'60b7dabf-99cd-41eb-b8e9-4d2e669bbde9','Ntext'),(20,1039,'cdbf0b5d-5cb2-445f-bc12-fcaaec07cf2c','Ntext'),(21,1040,'71b8ad1a-8dc2-425c-b6b8-faa158075e63','Ntext'),(22,1041,'4023e540-92f5-11dd-ad8b-0800200c9a66','Ntext'),(23,1042,'474fcff8-9d2d-11de-abc6-ad7a56d89593','Ntext'),(24,1043,'7a2d436c-34c2-410f-898f-4a23b3d79f54','Ntext');
/*!40000 ALTER TABLE `cmsdatatype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsdocument`
--

DROP TABLE IF EXISTS `cmsdocument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsdocument` (
  `nodeId` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `documentUser` int(11) NOT NULL,
  `versionId` char(36) NOT NULL,
  `text` varchar(255) NOT NULL,
  `releaseDate` timestamp NULL DEFAULT NULL,
  `expireDate` timestamp NULL DEFAULT NULL,
  `updateDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `templateId` int(11) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `newest` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`versionId`),
  KEY `templateId` (`templateId`),
  KEY `IX_cmsDocument` (`nodeId`,`versionId`),
  CONSTRAINT `cmsdocument_ibfk_1` FOREIGN KEY (`nodeId`) REFERENCES `umbraconode` (`id`),
  CONSTRAINT `cmsdocument_ibfk_2` FOREIGN KEY (`nodeId`) REFERENCES `cmscontent` (`nodeId`),
  CONSTRAINT `cmsdocument_ibfk_3` FOREIGN KEY (`templateId`) REFERENCES `cmstemplate` (`nodeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsdocument`
--

LOCK TABLES `cmsdocument` WRITE;
/*!40000 ALTER TABLE `cmsdocument` DISABLE KEYS */;
INSERT INTO `cmsdocument` VALUES (1074,0,0,'03fc47df-df58-4aed-8a42-593dba5a8467','Home Page',NULL,NULL,'2013-06-10 20:50:42',NULL,NULL,0),(1074,0,0,'0c1ad280-68b8-4b93-9cf2-9332681c3815','Home Page',NULL,NULL,'2013-06-10 20:50:31',NULL,NULL,0),(1066,0,0,'1495b5f7-8c2a-42e1-9f46-55cf6089d7d7','Our Business',NULL,NULL,'2013-05-06 17:22:34',1059,NULL,0),(1064,0,0,'14ae6a88-02ff-47b2-9157-d16b657ea5f8','Products',NULL,NULL,'2013-05-06 17:20:23',1059,NULL,0),(1064,0,0,'16264fe8-6a1a-42c7-82f1-b9362fa90572','Products',NULL,NULL,'2013-05-06 17:37:59',1059,NULL,0),(1061,0,0,'18c2505e-84e7-401a-884d-298eb1a4507e','HomePage',NULL,NULL,'2013-05-06 17:12:35',1059,NULL,0),(1063,0,0,'1900974f-075b-4d69-8e7f-a2ce06956b83','Contact Us',NULL,NULL,'2013-05-06 17:35:29',1059,NULL,0),(1064,0,0,'193b8a2f-bb95-4470-ab9f-9a9bd5a6211a','Products',NULL,NULL,'2013-05-06 17:35:47',1059,NULL,0),(1066,0,0,'1bb58018-edb1-4fcf-a4c8-b32356183262','Our Business',NULL,NULL,'2013-05-06 17:22:34',1059,NULL,0),(1067,0,0,'2374f9d1-f242-4fae-a57e-fae68dc55b80','Our Business',NULL,NULL,'2013-05-06 17:27:31',1059,NULL,0),(1082,0,0,'2d029673-3d4c-40ab-99cc-c302607f786d','About Us',NULL,NULL,'2013-06-11 00:46:11',1073,NULL,0),(1082,1,0,'2d43400e-8bb5-4318-b54e-c87247898ab5','About Us',NULL,NULL,'2013-06-11 00:49:14',1073,NULL,1),(1064,0,0,'2efd1b7c-3c27-44bd-bb2a-0d0369832d35','Products',NULL,NULL,'2013-05-06 17:20:24',1059,NULL,0),(1074,0,0,'30ebdca7-b9f5-4447-ac7c-0d2e6a769f22','Home Page',NULL,NULL,'2013-06-10 23:38:22',1073,NULL,0),(1062,1,0,'3520c8d1-eee7-4add-aaeb-00041ca2174d','About us',NULL,NULL,'2013-05-06 17:41:15',1059,NULL,1),(1066,1,0,'35c447d8-9fa1-4aa8-afe7-e97908a3583c','Our Business',NULL,NULL,'2013-05-06 17:41:15',1059,NULL,1),(1082,0,0,'3af08dc3-85d6-4b5c-b21e-7b5e01ae962c','About Us',NULL,NULL,'2013-06-11 00:46:19',1073,NULL,0),(1066,0,0,'3eeb8f28-afe7-41d3-b36f-684f4d66ee1c','Our Business',NULL,NULL,'2013-05-06 17:25:52',1059,NULL,0),(1062,0,0,'42de697d-2d07-411e-841f-8e897e0e90d0','About us',NULL,NULL,'2013-05-06 17:35:30',1059,NULL,0),(1061,0,0,'46640e05-3bae-47f7-aa3d-ac9f3e5a1d8e','HomePage',NULL,NULL,'2013-05-06 17:12:12',1059,NULL,0),(1067,1,0,'4927a34d-9d43-4d0f-8c8d-a3a226f42404','Our Business',NULL,NULL,'2013-05-06 17:27:31',1059,NULL,1),(1074,1,0,'4dc571a4-7358-4fa1-a674-78bfde232e80','Home Page',NULL,NULL,'2013-06-10 23:38:22',1073,NULL,1),(1074,0,0,'53a99c2e-3113-402a-a98a-384ebb035723','Home Page',NULL,NULL,'2013-06-10 20:53:29',1073,NULL,0),(1062,0,0,'54a32d32-f50e-4adf-965c-1a772772295a','About us',NULL,NULL,'2013-05-06 17:18:24',1059,NULL,0),(1061,0,0,'56f2c2d1-9ac9-4b80-bfe7-25c9b5da2ba3','HomePage',NULL,NULL,'2013-05-06 17:07:52',NULL,NULL,0),(1062,0,0,'5790c3f9-2e45-4515-90b9-3159806b903d','About us',NULL,NULL,'2013-05-06 17:18:02',1059,NULL,0),(1074,0,0,'5a1a174c-6f84-4c93-b7af-4f33f08e01c5','Home Page',NULL,NULL,'2013-06-10 20:51:45',NULL,NULL,0),(1074,0,0,'5ad27bbc-16df-4560-97e0-23a71aeb7c3c','Home Page',NULL,NULL,'2013-06-10 20:53:43',1073,NULL,0),(1061,0,0,'5d9ea0d1-dedc-4b7a-aa3d-a3bffd0e92bf','HomePage',NULL,NULL,'2013-05-06 17:05:03',NULL,NULL,0),(1061,0,0,'60833a6b-0a5d-4ccc-9dfd-213e979dbe7d','HomePage',NULL,NULL,'2013-05-06 17:05:33',NULL,NULL,0),(1063,1,0,'65affbce-3499-46f2-9172-d4fd4e2be979','Contact Us',NULL,NULL,'2013-05-06 17:35:29',1059,NULL,1),(1061,0,0,'781abae0-2b45-4688-bffe-c86c3042b76a','HomePage',NULL,NULL,'2013-05-06 17:12:13',1059,NULL,0),(1061,0,0,'7bf4385c-7b56-44eb-9005-9507745bcf58','HomePage',NULL,NULL,'2013-06-10 20:50:42',1059,NULL,1),(1082,0,0,'7d2aefa6-99a8-4f47-ac08-939adf7a83eb','About Us',NULL,NULL,'2013-06-11 00:49:14',1073,NULL,0),(1061,0,0,'821e4fb6-a6f5-417e-a407-2de56b7c28fb','HomePage',NULL,NULL,'2013-05-06 17:12:34',1059,NULL,0),(1062,0,0,'88727743-7961-479c-a4e7-14a14365ca0a','About us',NULL,NULL,'2013-05-06 17:35:30',1059,NULL,0),(1061,0,0,'88a2ee4e-151f-42cb-9813-3260764d726a','HomePage',NULL,NULL,'2013-05-06 17:07:52',NULL,NULL,0),(1062,0,0,'8c96354b-8823-4645-8e74-9d926640bb91','About us',NULL,NULL,'2013-05-06 17:18:02',1059,NULL,0),(1064,0,0,'8cd13135-c716-4c0a-8ced-f8aba7bb31f2','Products',NULL,NULL,'2013-05-06 17:35:47',1059,NULL,0),(1074,0,0,'9926b88d-d804-44da-97ad-5a95784d8ca2','Home Page',NULL,NULL,'2013-06-10 22:55:30',1073,NULL,0),(1063,0,0,'9d99984a-4155-4fd4-9fe4-554eab6b6c9e','Contact Us',NULL,NULL,'2013-05-06 17:19:41',1059,NULL,0),(1074,0,0,'a18add03-8c1e-4b62-b8ac-67e828b92c5f','Home Page',NULL,NULL,'2013-06-10 20:53:29',1073,NULL,0),(1061,0,0,'a60121ff-c9fe-4943-af9e-405c3921e911','HomePage',NULL,NULL,'2013-05-06 17:05:33',NULL,NULL,0),(1074,0,0,'adaa7989-762c-4224-899f-5840a448b16c','Home Page',NULL,NULL,'2013-06-10 20:50:42',NULL,NULL,0),(1082,0,0,'b6fb195d-f1cc-4af9-a454-933236852aea','About Us',NULL,NULL,'2013-06-11 00:47:05',1073,NULL,0),(1064,0,0,'b9c4b5d1-3c5f-4758-85c8-e7e2fdf33deb','Products',NULL,NULL,'2013-05-06 17:35:30',1059,NULL,0),(1082,0,0,'bd69e48b-ab13-4c0b-bd5f-7a7ffefafb8b','About Us',NULL,NULL,'2013-06-11 00:46:11',1073,NULL,0),(1074,0,0,'c41b4ce8-433d-4290-838a-ee12a0cb893d','Home Page',NULL,NULL,'2013-06-10 20:50:31',NULL,NULL,0),(1061,0,0,'c7db23da-ab44-49e7-84d5-c231ac9e44d6','HomePage',NULL,NULL,'2013-05-06 17:05:03',NULL,NULL,0),(1063,0,0,'c8f3842a-c66d-4930-9ace-6825f8b35581','Contact Us',NULL,NULL,'2013-05-06 17:19:41',1059,NULL,0),(1082,0,0,'c9caf9ec-39d9-40f6-ba9b-be9510c621bc','About Us',NULL,NULL,'2013-06-11 00:46:19',1073,NULL,0),(1074,0,0,'cf8a3123-00ca-4ac3-b418-d0d6489de38f','Home Page',NULL,NULL,'2013-06-10 20:53:43',1073,NULL,0),(1082,0,0,'d36dc3d8-4348-4588-b953-a9cc6cb80f37','About Us',NULL,NULL,'2013-06-11 00:47:05',1073,NULL,0),(1061,0,0,'dc5f75e6-2ddb-4bcf-8758-463db624e4d7','HomePage',NULL,NULL,'2013-05-06 17:13:04',1059,NULL,0),(1074,0,0,'eb8b6d64-cbec-49ee-b695-7d1de111ca04','Home Page',NULL,NULL,'2013-06-10 22:55:45',1073,NULL,0),(1074,0,0,'f4a2ec82-d7a3-45ca-9731-00be1fdc0ec4','Home Page',NULL,NULL,'2013-06-10 22:55:30',1073,NULL,0),(1064,1,0,'f9c10a21-668d-4005-8ebf-9e8eb1ee40f3','Products',NULL,NULL,'2013-05-06 17:40:58',1059,NULL,1),(1074,0,0,'fa18e13e-6198-4f8c-999c-b8d2a9431063','Home Page',NULL,NULL,'2013-06-10 22:55:44',1073,NULL,0),(1074,0,0,'fa728a68-36f8-4fad-a738-5e3d19eba52c','Home Page',NULL,NULL,'2013-06-10 20:51:45',NULL,NULL,0),(1062,0,0,'fff8f575-7681-4e14-9352-79e880e66ad3','About us',NULL,NULL,'2013-05-06 17:18:24',1059,NULL,0);
/*!40000 ALTER TABLE `cmsdocument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsmember`
--

DROP TABLE IF EXISTS `cmsmember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsmember` (
  `nodeId` int(11) NOT NULL,
  `Email` varchar(1000) NOT NULL DEFAULT '''',
  `LoginName` varchar(1000) NOT NULL DEFAULT '''',
  `Password` varchar(1000) NOT NULL DEFAULT '''',
  PRIMARY KEY (`nodeId`),
  CONSTRAINT `cmsmember_ibfk_1` FOREIGN KEY (`nodeId`) REFERENCES `umbraconode` (`id`),
  CONSTRAINT `cmsmember_ibfk_2` FOREIGN KEY (`nodeId`) REFERENCES `cmscontent` (`nodeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsmember`
--

LOCK TABLES `cmsmember` WRITE;
/*!40000 ALTER TABLE `cmsmember` DISABLE KEYS */;
INSERT INTO `cmsmember` VALUES (1055,'test@test.com','test','W477AMlLwwJQeAGlPZKiEILr8TA=');
/*!40000 ALTER TABLE `cmsmember` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmstagrelationship`
--

DROP TABLE IF EXISTS `cmstagrelationship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmstagrelationship` (
  `nodeId` int(11) NOT NULL,
  `tagId` int(11) NOT NULL,
  KEY `nodeId` (`nodeId`),
  KEY `tagId` (`tagId`),
  CONSTRAINT `cmstagrelationship_ibfk_1` FOREIGN KEY (`nodeId`) REFERENCES `umbraconode` (`id`),
  CONSTRAINT `cmstagrelationship_ibfk_2` FOREIGN KEY (`tagId`) REFERENCES `cmstags` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmstagrelationship`
--

LOCK TABLES `cmstagrelationship` WRITE;
/*!40000 ALTER TABLE `cmstagrelationship` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmstagrelationship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umbracodomains`
--

DROP TABLE IF EXISTS `umbracodomains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbracodomains` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domainDefaultLanguage` int(11) DEFAULT NULL,
  `domainRootStructureID` int(11) DEFAULT NULL,
  `domainName` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `domainRootStructureID` (`domainRootStructureID`),
  CONSTRAINT `umbracodomains_ibfk_1` FOREIGN KEY (`domainRootStructureID`) REFERENCES `umbraconode` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umbracodomains`
--

LOCK TABLES `umbracodomains` WRITE;
/*!40000 ALTER TABLE `umbracodomains` DISABLE KEYS */;
/*!40000 ALTER TABLE `umbracodomains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umbracolog`
--

DROP TABLE IF EXISTS `umbracolog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umbracolog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `NodeId` int(11) NOT NULL,
  `Datestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `logHeader` varchar(50) NOT NULL,
  `logComment` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_umbracoLog` (`NodeId`)
) ENGINE=InnoDB AUTO_INCREMENT=414 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umbracolog`
--

LOCK TABLES `umbracolog` WRITE;
/*!40000 ALTER TABLE `umbracolog` DISABLE KEYS */;
INSERT INTO `umbracolog` VALUES (1,0,-1,'2013-04-28 18:59:03','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(2,0,-1,'2013-04-28 19:01:00','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(3,0,-1,'2013-04-28 19:01:38','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(4,0,-1,'2013-04-28 19:38:14','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(5,0,-1,'2013-04-28 19:40:40','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(6,0,-1,'2013-04-28 19:44:14','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(7,0,-1,'2013-04-28 19:46:30','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(8,0,-1,'2013-04-28 19:50:42','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(9,0,-1,'2013-04-28 20:12:01','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(10,0,-1,'2013-04-28 20:21:09','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(11,0,-1,'2013-04-28 20:26:40','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(12,0,-1,'2013-04-28 20:35:12','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(13,0,-1,'2013-05-05 09:04:21','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(14,0,-1,'2013-05-05 09:07:01','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(15,0,-1,'2013-05-05 09:13:55','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(16,0,-1,'2013-05-05 09:19:53','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(17,0,-1,'2013-05-05 09:36:05','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(18,0,0,'2013-05-05 09:38:12','New',''),(19,0,1044,'2013-05-05 09:38:12','Save','Save Media performed by user'),(20,0,-1,'2013-05-05 09:55:18','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(21,0,1044,'2013-05-05 09:56:01','Move','Move Media to Recycle Bin performed by user'),(22,0,-1,'2013-05-05 09:59:11','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(23,0,-20,'2013-05-05 09:59:54','Delete','Empty Recycle Bin performed by user'),(24,0,0,'2013-05-05 10:00:15','New',''),(25,0,1045,'2013-05-05 10:00:15','Save','Save Media performed by user'),(26,0,-1,'2013-05-05 10:02:10','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(27,0,0,'2013-05-05 11:29:53','New',''),(28,0,1046,'2013-05-05 11:29:53','Save','Save Media performed by user'),(29,0,0,'2013-05-05 11:30:12','New',''),(30,0,1047,'2013-05-05 11:30:12','Save','Save Media performed by user'),(31,0,0,'2013-05-05 11:30:34','New',''),(32,0,1048,'2013-05-05 11:30:35','Save','Save Media performed by user'),(33,0,1046,'2013-05-05 11:31:39','Save','Save Media performed by user'),(34,0,1047,'2013-05-05 11:40:33','Save','Save Media performed by user'),(35,0,-1,'2013-05-05 11:45:00','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(36,0,1046,'2013-05-05 11:45:37','Save','Save Media performed by user'),(37,0,1046,'2013-05-05 11:46:08','Save','Save Media performed by user'),(38,0,1047,'2013-05-05 11:46:26','Save','Save Media performed by user'),(39,0,1047,'2013-05-05 11:46:54','Save','Save Media performed by user'),(40,0,0,'2013-05-05 11:48:23','New',''),(41,0,1049,'2013-05-05 11:48:23','Save','Save Media performed by user'),(42,0,1049,'2013-05-05 11:48:23','Save','Save Media performed by user'),(43,0,0,'2013-05-05 11:48:23','New',''),(44,0,1050,'2013-05-05 11:48:23','Save','Save Media performed by user'),(45,0,1050,'2013-05-05 11:48:23','Save','Save Media performed by user'),(46,0,0,'2013-05-05 11:48:23','New',''),(47,0,1051,'2013-05-05 11:48:24','Save','Save Media performed by user'),(48,0,1051,'2013-05-05 11:48:24','Save','Save Media performed by user'),(49,0,0,'2013-05-05 11:48:24','New',''),(50,0,1052,'2013-05-05 11:48:24','Save','Save Media performed by user'),(51,0,1052,'2013-05-05 11:48:24','Save','Save Media performed by user'),(52,0,-1,'2013-05-05 12:23:04','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(53,0,-1,'2013-05-05 12:27:10','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(54,0,-1,'2013-05-06 07:12:05','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(55,0,-1,'2013-05-06 07:18:21','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(56,0,-1,'2013-05-06 07:21:02','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(57,0,-1,'2013-05-06 07:24:07','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(58,0,-1,'2013-05-06 07:33:32','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(59,0,-1,'2013-05-06 07:35:59','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(60,0,-1,'2013-05-06 07:38:59','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(61,0,-1,'2013-05-06 07:41:07','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(62,0,-1,'2013-05-06 07:46:13','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(63,0,-1,'2013-05-06 08:00:30','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(64,0,-1,'2013-05-06 08:10:12','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(65,0,-1,'2013-05-06 08:20:44','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(66,0,-1,'2013-05-06 08:25:01','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(67,0,-1,'2013-05-06 08:28:38','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(68,0,-1,'2013-05-06 08:31:11','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(69,0,-1,'2013-05-06 08:49:14','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(70,0,-1,'2013-05-06 09:01:13','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(71,0,-1,'2013-05-06 09:12:57','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(72,0,-1,'2013-05-06 09:20:59','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(73,0,-1,'2013-05-06 09:22:48','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(74,0,-1,'2013-05-06 09:27:12','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(75,0,-1,'2013-05-06 09:32:46','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(76,0,1058,'2013-05-06 09:34:33','Save','Save ContentType performed by user'),(77,0,1058,'2013-05-06 09:34:33','Save','Save ContentType performed by user'),(78,0,-1,'2013-05-06 09:35:58','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(79,0,-1,'2013-05-06 09:37:53','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(80,0,-1,'2013-05-06 09:42:48','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(81,0,1058,'2013-05-06 09:54:06','Save','Save ContentType performed by user'),(82,0,-1,'2013-05-06 10:19:48','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(83,0,1058,'2013-05-06 10:20:49','Save','Save ContentType performed by user'),(84,0,1058,'2013-05-06 10:21:06','Save','Save ContentType performed by user'),(85,0,1058,'2013-05-06 10:21:13','Save','Save ContentType performed by user'),(86,0,1058,'2013-05-06 10:21:31','Save','Save ContentType performed by user'),(87,0,1058,'2013-05-06 10:21:32','Save','Save ContentType performed by user'),(88,0,-1,'2013-05-06 10:35:14','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(89,0,-1,'2013-05-06 10:36:35','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(90,0,1058,'2013-05-06 10:37:47','Save','Save ContentType performed by user'),(91,0,1058,'2013-05-06 10:37:54','Save','Save ContentType performed by user'),(92,0,1058,'2013-05-06 10:38:18','Save','Save ContentType performed by user'),(93,0,1058,'2013-05-06 10:38:41','Save','Save ContentType performed by user'),(94,0,-1,'2013-05-06 10:42:10','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(95,0,1031,'2013-05-06 10:42:43','Save','Save MediaType performed by user'),(96,0,1031,'2013-05-06 10:50:01','Save','Save MediaType performed by user'),(97,0,-1,'2013-05-06 11:00:39','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(98,0,1031,'2013-05-06 11:01:20','Save','Save MediaType performed by user'),(99,0,1060,'2013-05-06 11:01:45','Save','Save MediaType performed by user'),(100,0,1060,'2013-05-06 11:02:04','Save','Save MediaType performed by user'),(101,0,1060,'2013-05-06 11:07:47','Save','Save MediaType performed by user'),(102,0,1060,'2013-05-06 11:08:14','Save','Save MediaType performed by user'),(103,0,1060,'2013-05-06 11:08:37','Save','Save MediaType performed by user'),(104,0,-1,'2013-05-06 11:10:36','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(105,0,-1,'2013-05-06 14:56:04','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(106,0,-1,'2013-05-06 14:57:09','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(107,0,-1,'2013-05-06 14:59:37','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(108,0,-1,'2013-05-06 15:01:24','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(109,0,-1,'2013-05-06 15:04:47','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(110,0,-1,'2013-05-06 15:06:50','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(111,0,-1,'2013-05-06 15:12:54','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(112,0,-1,'2013-05-06 15:16:38','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(113,0,-1,'2013-05-06 15:21:50','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(114,0,-1,'2013-05-06 15:24:42','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(115,0,-1,'2013-05-06 15:30:19','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(116,0,-1,'2013-05-06 15:34:01','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(117,0,-1,'2013-05-06 15:35:49','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(118,0,-1,'2013-05-06 15:46:59','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(119,0,-1,'2013-05-06 15:52:45','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(120,0,-1,'2013-05-06 15:59:04','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(121,0,-1,'2013-05-06 16:18:38','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(122,0,-1,'2013-05-06 16:19:51','Save','Save ContentTypes performed by user'),(123,0,-1,'2013-05-06 16:25:24','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(124,0,-1,'2013-05-06 16:26:01','Save','Save ContentTypes performed by user'),(125,0,-1,'2013-05-06 16:47:31','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(126,0,-1,'2013-05-06 16:54:01','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(127,0,-1,'2013-05-06 16:55:27','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(128,0,-1,'2013-05-06 17:00:58','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(129,0,0,'2013-05-06 17:01:39','New',''),(130,0,1061,'2013-05-06 17:01:40','Save','Save Content performed by user'),(131,0,1061,'2013-05-06 17:01:40','Save','Save Content performed by user'),(132,0,1061,'2013-05-06 17:01:42','Open',''),(133,0,-1,'2013-05-06 17:04:24','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(134,0,1061,'2013-05-06 17:04:40','Open',''),(135,0,1061,'2013-05-06 17:05:03','Save','Save Content performed by user'),(136,0,1061,'2013-05-06 17:05:03','Publish','Save and Publish performed by user'),(137,0,1061,'2013-05-06 17:05:28','Open',''),(138,0,1061,'2013-05-06 17:05:33','Save','Save Content performed by user'),(139,0,1061,'2013-05-06 17:05:33','Publish','Save and Publish performed by user'),(140,0,-1,'2013-05-06 17:07:15','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(141,0,1061,'2013-05-06 17:07:38','Open',''),(142,0,1061,'2013-05-06 17:07:52','Save','Save Content performed by user'),(143,0,1061,'2013-05-06 17:07:53','Publish','Save and Publish performed by user'),(144,0,1058,'2013-05-06 17:10:57','Save','Save ContentType performed by user'),(145,0,1058,'2013-05-06 17:11:52','Save','Save ContentType performed by user'),(146,0,1061,'2013-05-06 17:12:02','Open',''),(147,0,1061,'2013-05-06 17:12:13','Save','Save Content performed by user'),(148,0,1061,'2013-05-06 17:12:13','Publish','Save and Publish performed by user'),(149,0,1061,'2013-05-06 17:12:35','Save','Save Content performed by user'),(150,0,1061,'2013-05-06 17:12:35','Publish','Save and Publish performed by user'),(151,0,1061,'2013-05-06 17:13:04','Save','Save Content performed by user'),(152,0,1061,'2013-05-06 17:13:04','Publish','Save and Publish performed by user'),(153,0,1058,'2013-05-06 17:15:04','Save','Save ContentType performed by user'),(154,0,1061,'2013-05-06 17:15:09','Open',''),(155,0,1061,'2013-05-06 17:15:24','Open',''),(156,0,0,'2013-05-06 17:15:50','New',''),(157,0,1062,'2013-05-06 17:15:50','Save','Save Content performed by user'),(158,0,1062,'2013-05-06 17:15:50','Save','Save Content performed by user'),(159,0,1062,'2013-05-06 17:15:51','Open',''),(160,0,-1,'2013-05-06 17:17:37','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(161,0,1062,'2013-05-06 17:17:48','Open',''),(162,0,1062,'2013-05-06 17:18:02','Save','Save Content performed by user'),(163,0,1062,'2013-05-06 17:18:02','Publish','Save and Publish performed by user'),(164,0,1062,'2013-05-06 17:18:24','Save','Save Content performed by user'),(165,0,1062,'2013-05-06 17:18:24','Publish','Save and Publish performed by user'),(166,0,0,'2013-05-06 17:19:26','New',''),(167,0,1063,'2013-05-06 17:19:27','Save','Save Content performed by user'),(168,0,1063,'2013-05-06 17:19:27','Save','Save Content performed by user'),(169,0,1063,'2013-05-06 17:19:28','Open',''),(170,0,1063,'2013-05-06 17:19:41','Save','Save Content performed by user'),(171,0,1063,'2013-05-06 17:19:42','Publish','Save and Publish performed by user'),(172,0,0,'2013-05-06 17:20:02','New',''),(173,0,1064,'2013-05-06 17:20:02','Save','Save Content performed by user'),(174,0,1064,'2013-05-06 17:20:02','Save','Save Content performed by user'),(175,0,1064,'2013-05-06 17:20:03','Open',''),(176,0,1064,'2013-05-06 17:20:23','Save','Save Content performed by user'),(177,0,1064,'2013-05-06 17:20:24','Publish','Save and Publish performed by user'),(178,0,0,'2013-05-06 17:21:00','New',''),(179,0,1065,'2013-05-06 17:21:00','Save','Save Content performed by user'),(180,0,1065,'2013-05-06 17:21:00','Save','Save Content performed by user'),(181,0,1065,'2013-05-06 17:21:01','Open',''),(182,0,1065,'2013-05-06 17:21:05','Save','Save Content performed by user'),(183,0,1065,'2013-05-06 17:21:05','Publish','Save and Publish performed by user'),(184,0,1065,'2013-05-06 17:21:34','Open',''),(185,0,1065,'2013-05-06 17:21:41','Delete',''),(186,0,1065,'2013-05-06 17:21:41','UnPublish','UnPublish performed by user'),(187,0,1065,'2013-05-06 17:21:41','UnPublish','UnPublish performed by user'),(188,0,1065,'2013-05-06 17:21:41','Move','Move Content to Recycle Bin performed by user'),(189,0,-20,'2013-05-06 17:21:50','Delete','Empty Recycle Bin performed by user'),(190,0,0,'2013-05-06 17:22:20','New',''),(191,0,1066,'2013-05-06 17:22:20','Save','Save Content performed by user'),(192,0,1066,'2013-05-06 17:22:21','Save','Save Content performed by user'),(193,0,1066,'2013-05-06 17:22:22','Open',''),(194,0,1066,'2013-05-06 17:22:34','Save','Save Content performed by user'),(195,0,1066,'2013-05-06 17:22:34','Publish','Save and Publish performed by user'),(196,0,-1,'2013-05-06 17:25:03','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(197,0,1066,'2013-05-06 17:25:19','Open',''),(198,0,1066,'2013-05-06 17:25:52','Publish','Save and Publish performed by user'),(199,0,1066,'2013-05-06 17:25:52','Move','Move Content performed by user'),(200,0,1066,'2013-05-06 17:25:54','Open',''),(201,0,1066,'2013-05-06 17:26:48','Copy','Copy Content performed by user'),(202,0,1067,'2013-05-06 17:26:49','Save','Save Content performed by user'),(203,0,1067,'2013-05-06 17:27:13','Open',''),(204,0,1067,'2013-05-06 17:27:31','Save','Save Content performed by user'),(205,0,1067,'2013-05-06 17:27:31','Publish','Save and Publish performed by user'),(206,0,1063,'2013-05-06 17:27:48','Open',''),(207,0,-1,'2013-05-06 17:30:51','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(208,0,-1,'2013-05-06 17:33:03','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(209,0,-1,'2013-05-06 17:34:54','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(210,0,1063,'2013-05-06 17:35:29','Save','Save Content performed by user'),(211,0,1063,'2013-05-06 17:35:29','Publish','Save and Publish performed by user'),(212,0,1062,'2013-05-06 17:35:30','Save','Save Content performed by user'),(213,0,1062,'2013-05-06 17:35:30','Publish','Save and Publish performed by user'),(214,0,1064,'2013-05-06 17:35:30','Save','Save Content performed by user'),(215,0,1064,'2013-05-06 17:35:30','Publish','Save and Publish performed by user'),(216,0,1064,'2013-05-06 17:35:39','Open',''),(217,0,1064,'2013-05-06 17:35:47','Save','Save Content performed by user'),(218,0,1064,'2013-05-06 17:35:48','Publish','Save and Publish performed by user'),(219,0,-1,'2013-05-06 17:37:04','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(220,0,1064,'2013-05-06 17:37:12','Open',''),(221,0,1064,'2013-05-06 17:37:59','RollBack','Content rollback performed by user'),(222,0,1064,'2013-05-06 17:37:59','RollBack','Version rolled back to revision \'16264fe8-6a1a-42c7-82f1-b9362fa90572\''),(223,0,1064,'2013-05-06 17:38:00','Open',''),(224,0,-1,'2013-05-06 17:40:10','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(225,0,1064,'2013-05-06 17:40:34','Open',''),(226,0,1064,'2013-05-06 17:40:59','Publish','Save and Publish performed by user'),(227,0,1062,'2013-05-06 17:41:15','Publish','Save and Publish performed by user'),(228,0,1066,'2013-05-06 17:41:15','Publish','Save and Publish performed by user'),(229,0,-1,'2013-05-06 17:42:19','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(230,0,1066,'2013-05-06 17:48:09','SendToTranslate','Translator: TestTranslator, Language: English (United Kingdom)'),(231,0,-1,'2013-06-08 09:35:55','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(232,0,-1,'2013-06-08 09:47:34','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(233,0,-1,'2013-06-08 09:48:11','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(234,0,1061,'2013-06-08 10:06:57','Open',''),(235,1,1064,'2013-06-08 10:08:07','Open',''),(236,0,1061,'2013-06-08 10:13:07','Open',''),(237,0,1061,'2013-06-08 10:15:33','Open',''),(238,0,1061,'2013-06-08 10:15:52','Open',''),(239,0,-1,'2013-06-08 10:19:07','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(240,0,-1,'2013-06-08 10:21:17','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(241,0,-1,'2013-06-08 16:22:39','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(242,0,-1,'2013-06-08 18:03:01','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(243,0,-1,'2013-06-08 18:51:23','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(244,0,-1,'2013-06-08 22:57:09','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(245,0,-1,'2013-06-08 23:10:11','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(246,0,1064,'2013-06-08 23:11:40','Open',''),(247,0,-1,'2013-06-08 23:29:49','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(248,0,-1,'2013-06-08 23:34:58','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(249,0,-1,'2013-06-09 14:36:02','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(250,0,-1,'2013-06-09 14:47:35','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(251,0,-1,'2013-06-09 19:25:41','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(252,0,-1,'2013-06-09 19:32:21','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(253,0,-1,'2013-06-09 19:33:44','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(254,0,-1,'2013-06-09 19:56:10','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(255,0,-1,'2013-06-09 21:12:29','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(256,0,-1,'2013-06-09 22:02:04','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(257,0,-1,'2013-06-09 22:14:26','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(258,0,-1,'2013-06-09 22:15:51','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(259,0,-1,'2013-06-09 23:09:09','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(260,0,-1,'2013-06-09 23:34:32','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(261,0,-1,'2013-06-09 23:39:27','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(262,0,-1,'2013-06-09 23:45:16','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(263,0,-1,'2013-06-09 23:49:21','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(264,0,-1,'2013-06-09 23:54:15','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(265,0,-1,'2013-06-10 00:04:43','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(266,0,-1,'2013-06-10 00:10:05','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(267,0,-1,'2013-06-10 00:14:13','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(268,0,-1,'2013-06-10 19:37:47','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(269,0,-1,'2013-06-10 19:56:18','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(270,0,-1,'2013-06-10 20:10:43','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(271,0,1068,'2013-06-10 20:11:45','Save','Save ContentType performed by user'),(272,0,1068,'2013-06-10 20:11:45','Save','Save ContentType performed by user'),(273,0,1070,'2013-06-10 20:12:13','Save','Save ContentType performed by user'),(274,0,1070,'2013-06-10 20:12:13','Save','Save ContentType performed by user'),(275,0,-1,'2013-06-10 20:12:43','Delete','Delete Content of Type 1068 performed by user'),(276,0,1068,'2013-06-10 20:12:43','Delete','Delete ContentType performed by user'),(277,0,1072,'2013-06-10 20:12:53','Save','Save ContentType performed by user'),(278,0,1072,'2013-06-10 20:12:53','Save','Save ContentType performed by user'),(279,0,1070,'2013-06-10 20:13:31','Save','Save ContentType performed by user'),(280,0,1072,'2013-06-10 20:14:00','Save','Save ContentType performed by user'),(281,0,1070,'2013-06-10 20:14:14','Save','Save ContentType performed by user'),(282,0,1070,'2013-06-10 20:14:17','Save','Save ContentType performed by user'),(283,0,1070,'2013-06-10 20:14:32','Save','Save ContentType performed by user'),(284,0,1072,'2013-06-10 20:14:44','Save','Save ContentType performed by user'),(285,0,1072,'2013-06-10 20:15:01','Save','Save ContentType performed by user'),(286,0,-1,'2013-06-10 20:49:04','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(287,0,1061,'2013-06-10 20:49:18','Open',''),(288,0,1061,'2013-06-10 20:49:32','UnPublish','UnPublish performed by user'),(289,0,0,'2013-06-10 20:50:25','New',''),(290,0,1074,'2013-06-10 20:50:25','Save','Save Content performed by user'),(291,0,1074,'2013-06-10 20:50:25','Save','Save Content performed by user'),(292,0,1074,'2013-06-10 20:50:26','Open',''),(293,0,1074,'2013-06-10 20:50:31','Save','Save Content performed by user'),(294,0,1074,'2013-06-10 20:50:31','Publish','Save and Publish performed by user'),(295,0,1074,'2013-06-10 20:50:42','Save','Save Content performed by user'),(296,0,1074,'2013-06-10 20:50:42','Publish','Save and Publish performed by user'),(297,0,1061,'2013-06-10 20:50:42','Save','Save Content performed by user'),(298,0,1074,'2013-06-10 20:51:45','Save','Save Content performed by user'),(299,0,1074,'2013-06-10 20:51:45','Publish','Save and Publish performed by user'),(300,0,1072,'2013-06-10 20:53:03','Save','Save ContentType performed by user'),(301,0,1074,'2013-06-10 20:53:24','Open',''),(302,0,1074,'2013-06-10 20:53:29','Save','Save Content performed by user'),(303,0,1074,'2013-06-10 20:53:29','Publish','Save and Publish performed by user'),(304,0,1074,'2013-06-10 20:53:43','Save','Save Content performed by user'),(305,0,1074,'2013-06-10 20:53:43','Publish','Save and Publish performed by user'),(306,0,-1,'2013-06-10 20:56:29','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(307,0,-1,'2013-06-10 20:57:14','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(308,0,-1,'2013-06-10 21:03:04','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(309,0,-1,'2013-06-10 21:07:16','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(310,0,-1,'2013-06-10 21:08:45','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(311,0,-1,'2013-06-10 21:10:36','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(312,0,-1,'2013-06-10 21:10:55','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(313,0,-1,'2013-06-10 21:12:15','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(314,0,-1,'2013-06-10 21:14:47','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(315,0,-1,'2013-06-10 21:27:44','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(316,0,-1,'2013-06-10 21:30:06','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(317,0,-1,'2013-06-10 21:43:46','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(318,0,-1,'2013-06-10 21:45:30','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(319,0,-1,'2013-06-10 21:48:27','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(320,0,-1,'2013-06-10 22:04:29','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(321,0,0,'2013-06-10 22:04:49','New',''),(322,0,1075,'2013-06-10 22:04:50','Save','Save Media performed by user'),(323,0,-1,'2013-06-10 22:07:49','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(324,0,1076,'2013-06-10 22:09:00','Save','Save MediaType performed by user'),(325,0,1076,'2013-06-10 22:09:30','Save','Save MediaType performed by user'),(326,0,1076,'2013-06-10 22:09:45','Save','Save MediaType performed by user'),(327,0,1076,'2013-06-10 22:10:01','Save','Save MediaType performed by user'),(328,0,1076,'2013-06-10 22:10:41','Save','Save MediaType performed by user'),(329,0,1076,'2013-06-10 22:11:22','Save','Save MediaType performed by user'),(330,0,1076,'2013-06-10 22:11:43','Save','Save MediaType performed by user'),(331,0,1076,'2013-06-10 22:12:12','Save','Save MediaType performed by user'),(332,0,1076,'2013-06-10 22:12:41','Save','Save MediaType performed by user'),(333,0,-1,'2013-06-10 22:15:50','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(334,0,0,'2013-06-10 22:16:47','New',''),(335,0,-1,'2013-06-10 22:17:52','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(336,0,0,'2013-06-10 22:19:07','New',''),(337,0,-1,'2013-06-10 22:21:15','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(338,0,0,'2013-06-10 22:21:26','New',''),(339,0,1077,'2013-06-10 22:21:27','Save','Save Media performed by user'),(340,0,1075,'2013-06-10 22:22:13','Move','Move Media to Recycle Bin performed by user'),(341,0,-1,'2013-06-10 22:49:19','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(342,0,-1,'2013-06-10 22:49:53','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(343,0,0,'2013-06-10 22:50:43','New',''),(344,0,1078,'2013-06-10 22:50:43','Save','Save Media performed by user'),(345,0,-1,'2013-06-10 22:51:42','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(346,0,-1,'2013-06-10 22:54:53','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(347,0,1074,'2013-06-10 22:55:19','Open',''),(348,0,1074,'2013-06-10 22:55:30','Save','Save Content performed by user'),(349,0,1074,'2013-06-10 22:55:30','Publish','Save and Publish performed by user'),(350,0,1074,'2013-06-10 22:55:44','Save','Save Content performed by user'),(351,0,1074,'2013-06-10 22:55:45','Publish','Save and Publish performed by user'),(352,0,-1,'2013-06-10 22:56:29','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(353,0,-1,'2013-06-10 22:57:55','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(354,0,-1,'2013-06-10 22:59:54','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(355,0,-1,'2013-06-10 23:04:39','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(356,0,-1,'2013-06-10 23:12:04','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(357,0,-1,'2013-06-10 23:23:20','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(358,0,-1,'2013-06-10 23:25:13','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(359,0,-1,'2013-06-10 23:27:06','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(360,0,0,'2013-06-10 23:36:42','New',''),(361,0,1079,'2013-06-10 23:36:44','Save','Save Media performed by user'),(362,0,1077,'2013-06-10 23:37:12','Move','Move Media to Recycle Bin performed by user'),(363,0,1078,'2013-06-10 23:37:19','Move','Move Media to Recycle Bin performed by user'),(364,0,1074,'2013-06-10 23:38:09','Open',''),(365,0,1074,'2013-06-10 23:38:22','Save','Save Content performed by user'),(366,0,1074,'2013-06-10 23:38:22','Publish','Save and Publish performed by user'),(367,0,-1,'2013-06-10 23:39:43','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(368,0,1077,'2013-06-10 23:40:19','Delete','Delete Media performed by user'),(369,0,-1,'2013-06-10 23:41:54','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(370,0,0,'2013-06-10 23:44:14','New',''),(371,0,1080,'2013-06-10 23:44:15','Save','Save Media performed by user'),(372,0,0,'2013-06-10 23:44:34','New',''),(373,0,1081,'2013-06-10 23:44:35','Save','Save Media performed by user'),(374,0,-1,'2013-06-10 23:55:52','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(375,0,-1,'2013-06-10 23:57:12','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(376,0,-1,'2013-06-11 00:02:48','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(377,0,-1,'2013-06-11 00:05:28','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(378,0,-1,'2013-06-11 00:06:31','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(379,0,-1,'2013-06-11 00:09:04','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(380,0,-1,'2013-06-11 00:14:55','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(381,0,-1,'2013-06-11 00:16:06','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(382,0,-1,'2013-06-11 00:19:43','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(383,0,-1,'2013-06-11 00:21:41','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(384,0,-1,'2013-06-11 00:23:33','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(385,0,-1,'2013-06-11 00:24:57','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(386,0,-1,'2013-06-11 00:25:25','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(387,0,-1,'2013-06-11 00:26:07','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(388,0,-1,'2013-06-11 00:32:13','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(389,0,-1,'2013-06-11 00:34:18','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(390,0,-1,'2013-06-11 00:37:47','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(391,0,-1,'2013-06-11 00:38:32','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(392,0,-1,'2013-06-11 00:39:01','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(393,0,-1,'2013-06-11 00:41:11','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(394,0,-1,'2013-06-11 00:41:44','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(395,0,1074,'2013-06-11 00:42:23','Open',''),(396,0,-1,'2013-06-11 00:44:58','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(397,0,1072,'2013-06-11 00:45:53','Save','Save ContentType performed by user'),(398,0,1074,'2013-06-11 00:45:58','Open',''),(399,0,0,'2013-06-11 00:46:06','New',''),(400,0,1082,'2013-06-11 00:46:06','Save','Save Content performed by user'),(401,0,1082,'2013-06-11 00:46:06','Save','Save Content performed by user'),(402,0,1082,'2013-06-11 00:46:07','Open',''),(403,0,1082,'2013-06-11 00:46:11','Save','Save Content performed by user'),(404,0,1082,'2013-06-11 00:46:11','Publish','Save and Publish performed by user'),(405,0,1082,'2013-06-11 00:46:19','Save','Save Content performed by user'),(406,0,1082,'2013-06-11 00:46:19','Publish','Save and Publish performed by user'),(407,0,1082,'2013-06-11 00:47:05','Save','Save Content performed by user'),(408,0,1082,'2013-06-11 00:47:05','Publish','Save and Publish performed by user'),(409,0,1082,'2013-06-11 00:49:14','Save','Save Content performed by user'),(410,0,1082,'2013-06-11 00:49:14','Publish','Save and Publish performed by user'),(411,0,-1,'2013-06-11 00:57:07','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(412,0,-1,'2013-06-11 01:04:17','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2'),(413,0,-1,'2013-06-11 01:07:40','Custom','[UmbracoExamine] Adding examine event handlers for index providers: 2');
/*!40000 ALTER TABLE `umbracolog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmspreviewxml`
--

DROP TABLE IF EXISTS `cmspreviewxml`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmspreviewxml` (
  `nodeId` int(11) NOT NULL,
  `versionId` char(36) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `xml` longtext NOT NULL,
  KEY `nodeId` (`nodeId`),
  KEY `versionId` (`versionId`),
  CONSTRAINT `cmspreviewxml_ibfk_1` FOREIGN KEY (`nodeId`) REFERENCES `cmscontent` (`nodeId`),
  CONSTRAINT `cmspreviewxml_ibfk_2` FOREIGN KEY (`versionId`) REFERENCES `cmscontentversion` (`VersionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmspreviewxml`
--

LOCK TABLES `cmspreviewxml` WRITE;
/*!40000 ALTER TABLE `cmspreviewxml` DISABLE KEYS */;
INSERT INTO `cmspreviewxml` VALUES (1061,'c7db23da-ab44-49e7-84d5-c231ac9e44d6','2013-05-06 17:05:03','<TestDocumentType id=\"1061\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:01:40\" updateDate=\"2013-05-06T18:05:03\" nodeName=\"HomePage\" urlName=\"homepage\" path=\"-1,1061\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"0\">\r\n  <title xmlns=\"\"></title>\r\n  <bodyContent xmlns=\"\"><![CDATA[]]></bodyContent>\r\n</TestDocumentType>'),(1061,'5d9ea0d1-dedc-4b7a-aa3d-a3bffd0e92bf','2013-05-06 17:05:03','<TestDocumentType id=\"1061\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:01:40\" updateDate=\"2013-05-06T18:05:03\" nodeName=\"HomePage\" urlName=\"homepage\" path=\"-1,1061\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"0\">\r\n  <title xmlns=\"\"></title>\r\n  <bodyContent xmlns=\"\"><![CDATA[]]></bodyContent>\r\n</TestDocumentType>'),(1061,'a60121ff-c9fe-4943-af9e-405c3921e911','2013-05-06 17:05:33','<TestDocumentType id=\"1061\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:01:40\" updateDate=\"2013-05-06T18:05:33\" nodeName=\"HomePage\" urlName=\"homepage\" path=\"-1,1061\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"0\">\r\n  <title xmlns=\"\"></title>\r\n  <bodyContent xmlns=\"\"><![CDATA[]]></bodyContent>\r\n</TestDocumentType>'),(1061,'60833a6b-0a5d-4ccc-9dfd-213e979dbe7d','2013-05-06 17:05:33','<TestDocumentType id=\"1061\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:01:40\" updateDate=\"2013-05-06T18:05:33\" nodeName=\"HomePage\" urlName=\"homepage\" path=\"-1,1061\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"0\">\r\n  <title xmlns=\"\"></title>\r\n  <bodyContent xmlns=\"\"><![CDATA[]]></bodyContent>\r\n</TestDocumentType>'),(1061,'56f2c2d1-9ac9-4b80-bfe7-25c9b5da2ba3','2013-05-06 17:07:52','<TestDocumentType id=\"1061\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:01:40\" updateDate=\"2013-05-06T18:07:52\" nodeName=\"HomePage\" urlName=\"homepage\" path=\"-1,1061\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"0\">\r\n  <title xmlns=\"\"></title>\r\n  <bodyContent xmlns=\"\"><![CDATA[]]></bodyContent>\r\n</TestDocumentType>'),(1061,'88a2ee4e-151f-42cb-9813-3260764d726a','2013-05-06 17:07:53','<TestDocumentType id=\"1061\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:01:40\" updateDate=\"2013-05-06T18:07:52\" nodeName=\"HomePage\" urlName=\"homepage\" path=\"-1,1061\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"0\">\r\n  <title xmlns=\"\"></title>\r\n  <bodyContent xmlns=\"\"><![CDATA[]]></bodyContent>\r\n</TestDocumentType>'),(1061,'46640e05-3bae-47f7-aa3d-ac9f3e5a1d8e','2013-05-06 17:12:13','<TestDocumentType id=\"1061\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:01:40\" updateDate=\"2013-05-06T18:12:12\" nodeName=\"HomePage\" urlName=\"homepage\" path=\"-1,1061\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Page Title</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[]]></bodyContent>\r\n</TestDocumentType>'),(1061,'781abae0-2b45-4688-bffe-c86c3042b76a','2013-05-06 17:12:13','<TestDocumentType id=\"1061\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:01:40\" updateDate=\"2013-05-06T18:12:13\" nodeName=\"HomePage\" urlName=\"homepage\" path=\"-1,1061\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Page Title</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[]]></bodyContent>\r\n</TestDocumentType>'),(1061,'821e4fb6-a6f5-417e-a407-2de56b7c28fb','2013-05-06 17:12:35','<TestDocumentType id=\"1061\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:01:40\" updateDate=\"2013-05-06T18:12:34\" nodeName=\"HomePage\" urlName=\"homepage\" path=\"-1,1061\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Page Title</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>This is some text</p>]]></bodyContent>\r\n</TestDocumentType>'),(1061,'18c2505e-84e7-401a-884d-298eb1a4507e','2013-05-06 17:12:35','<TestDocumentType id=\"1061\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:01:40\" updateDate=\"2013-05-06T18:12:35\" nodeName=\"HomePage\" urlName=\"homepage\" path=\"-1,1061\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Page Title</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>This is some text</p>]]></bodyContent>\r\n</TestDocumentType>'),(1061,'dc5f75e6-2ddb-4bcf-8758-463db624e4d7','2013-05-06 17:13:04','<TestDocumentType id=\"1061\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:01:40\" updateDate=\"2013-05-06T18:13:04\" nodeName=\"HomePage\" urlName=\"homepage\" path=\"-1,1061\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Page Title</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>This is some text</p>]]></bodyContent>\r\n</TestDocumentType>'),(1061,'7bf4385c-7b56-44eb-9005-9507745bcf58','2013-06-10 20:50:42','<TestDocumentType id=\"1061\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-05-06T18:01:40\" updateDate=\"2013-06-10T21:50:42\" nodeName=\"HomePage\" urlName=\"homepage\" path=\"-1,1061\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Page Title</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>This is some text</p>]]></bodyContent>\r\n</TestDocumentType>'),(1062,'5790c3f9-2e45-4515-90b9-3159806b903d','2013-05-06 17:18:02','<TestDocumentType id=\"1062\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:15:50\" updateDate=\"2013-05-06T18:18:02\" nodeName=\"About us\" urlName=\"about-us\" path=\"-1,1061,1062\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">About us</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>This is the about us page.</p>]]></bodyContent>\r\n</TestDocumentType>'),(1062,'8c96354b-8823-4645-8e74-9d926640bb91','2013-05-06 17:18:02','<TestDocumentType id=\"1062\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:15:50\" updateDate=\"2013-05-06T18:18:02\" nodeName=\"About us\" urlName=\"about-us\" path=\"-1,1061,1062\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">About us</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>This is the about us page.</p>]]></bodyContent>\r\n</TestDocumentType>'),(1062,'fff8f575-7681-4e14-9352-79e880e66ad3','2013-05-06 17:18:24','<TestDocumentType id=\"1062\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:15:50\" updateDate=\"2013-05-06T18:18:24\" nodeName=\"About us\" urlName=\"about-us\" path=\"-1,1061,1062\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">About us</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>This is the about us page.</p>]]></bodyContent>\r\n</TestDocumentType>'),(1062,'54a32d32-f50e-4adf-965c-1a772772295a','2013-05-06 17:18:24','<TestDocumentType id=\"1062\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:15:50\" updateDate=\"2013-05-06T18:18:24\" nodeName=\"About us\" urlName=\"about-us\" path=\"-1,1061,1062\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">About us</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>This is the about us page.</p>]]></bodyContent>\r\n</TestDocumentType>'),(1063,'c8f3842a-c66d-4930-9ace-6825f8b35581','2013-05-06 17:19:41','<TestDocumentType id=\"1063\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-05-06T18:19:26\" updateDate=\"2013-05-06T18:19:41\" nodeName=\"Contact Us\" urlName=\"contact-us\" path=\"-1,1061,1063\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Contact Us</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Contact Us page</p>]]></bodyContent>\r\n</TestDocumentType>'),(1063,'9d99984a-4155-4fd4-9fe4-554eab6b6c9e','2013-05-06 17:19:41','<TestDocumentType id=\"1063\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-05-06T18:19:26\" updateDate=\"2013-05-06T18:19:41\" nodeName=\"Contact Us\" urlName=\"contact-us\" path=\"-1,1061,1063\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Contact Us</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Contact Us page</p>]]></bodyContent>\r\n</TestDocumentType>'),(1064,'14ae6a88-02ff-47b2-9157-d16b657ea5f8','2013-05-06 17:20:23','<TestDocumentType id=\"1064\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"2\" createDate=\"2013-05-06T18:20:02\" updateDate=\"2013-05-06T18:20:23\" nodeName=\"Products\" urlName=\"products\" path=\"-1,1061,1064\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Products</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Products Page List</p>]]></bodyContent>\r\n</TestDocumentType>'),(1064,'2efd1b7c-3c27-44bd-bb2a-0d0369832d35','2013-05-06 17:20:24','<TestDocumentType id=\"1064\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"2\" createDate=\"2013-05-06T18:20:02\" updateDate=\"2013-05-06T18:20:24\" nodeName=\"Products\" urlName=\"products\" path=\"-1,1061,1064\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Products</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Products Page List</p>]]></bodyContent>\r\n</TestDocumentType>'),(1066,'1bb58018-edb1-4fcf-a4c8-b32356183262','2013-05-06 17:22:34','<TestDocumentType id=\"1066\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"3\" createDate=\"2013-05-06T18:22:20\" updateDate=\"2013-05-06T18:22:34\" nodeName=\"Our Business\" urlName=\"our-business\" path=\"-1,1061,1066\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Our Business</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Our Business page</p>]]></bodyContent>\r\n</TestDocumentType>'),(1066,'1495b5f7-8c2a-42e1-9f46-55cf6089d7d7','2013-05-06 17:22:34','<TestDocumentType id=\"1066\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"3\" createDate=\"2013-05-06T18:22:20\" updateDate=\"2013-05-06T18:22:34\" nodeName=\"Our Business\" urlName=\"our-business\" path=\"-1,1061,1066\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Our Business</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Our Business page</p>]]></bodyContent>\r\n</TestDocumentType>'),(1066,'3eeb8f28-afe7-41d3-b36f-684f4d66ee1c','2013-05-06 17:25:52','<TestDocumentType id=\"1066\" parentID=\"1062\" level=\"3\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-05-06T18:22:20\" updateDate=\"2013-05-06T18:25:52\" nodeName=\"Our Business\" urlName=\"our-business\" path=\"-1,1061,1062,1066\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Our Business</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Our Business page</p>]]></bodyContent>\r\n</TestDocumentType>'),(1067,'2374f9d1-f242-4fae-a57e-fae68dc55b80','2013-05-06 17:27:31','<TestDocumentType id=\"1067\" parentID=\"1063\" level=\"3\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:26:48\" updateDate=\"2013-05-06T18:27:31\" nodeName=\"Our Business\" urlName=\"our-business\" path=\"-1,1061,1063,1067\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Our Head Office</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Head office page</p>]]></bodyContent>\r\n</TestDocumentType>'),(1067,'4927a34d-9d43-4d0f-8c8d-a3a226f42404','2013-05-06 17:27:31','<TestDocumentType id=\"1067\" parentID=\"1063\" level=\"3\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:26:48\" updateDate=\"2013-05-06T18:27:31\" nodeName=\"Our Business\" urlName=\"our-business\" path=\"-1,1061,1063,1067\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Our Head Office</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Head office page</p>]]></bodyContent>\r\n</TestDocumentType>'),(1063,'1900974f-075b-4d69-8e7f-a2ce06956b83','2013-05-06 17:35:29','<TestDocumentType id=\"1063\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:19:26\" updateDate=\"2013-05-06T18:35:29\" nodeName=\"Contact Us\" urlName=\"contact-us\" path=\"-1,1061,1063\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Contact Us</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Contact Us page</p>]]></bodyContent>\r\n</TestDocumentType>'),(1063,'65affbce-3499-46f2-9172-d4fd4e2be979','2013-05-06 17:35:29','<TestDocumentType id=\"1063\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-05-06T18:19:26\" updateDate=\"2013-05-06T18:35:29\" nodeName=\"Contact Us\" urlName=\"contact-us\" path=\"-1,1061,1063\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Contact Us</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Contact Us page</p>]]></bodyContent>\r\n</TestDocumentType>'),(1062,'42de697d-2d07-411e-841f-8e897e0e90d0','2013-05-06 17:35:30','<TestDocumentType id=\"1062\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-05-06T18:15:50\" updateDate=\"2013-05-06T18:35:30\" nodeName=\"About us\" urlName=\"about-us\" path=\"-1,1061,1062\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">About us</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>This is the about us page.</p>]]></bodyContent>\r\n</TestDocumentType>'),(1062,'88727743-7961-479c-a4e7-14a14365ca0a','2013-05-06 17:35:30','<TestDocumentType id=\"1062\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-05-06T18:15:50\" updateDate=\"2013-05-06T18:35:30\" nodeName=\"About us\" urlName=\"about-us\" path=\"-1,1061,1062\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">About us</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>This is the about us page.</p>]]></bodyContent>\r\n</TestDocumentType>'),(1064,'16264fe8-6a1a-42c7-82f1-b9362fa90572','2013-05-06 17:35:30','<TestDocumentType id=\"1064\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"2\" createDate=\"2013-05-06T18:20:02\" updateDate=\"2013-05-06T18:35:30\" nodeName=\"Products\" urlName=\"products\" path=\"-1,1061,1064\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Products</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Products Page List</p>]]></bodyContent>\r\n</TestDocumentType>'),(1064,'b9c4b5d1-3c5f-4758-85c8-e7e2fdf33deb','2013-05-06 17:35:30','<TestDocumentType id=\"1064\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"2\" createDate=\"2013-05-06T18:20:02\" updateDate=\"2013-05-06T18:35:30\" nodeName=\"Products\" urlName=\"products\" path=\"-1,1061,1064\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Products</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Products Page List</p>]]></bodyContent>\r\n</TestDocumentType>'),(1064,'193b8a2f-bb95-4470-ab9f-9a9bd5a6211a','2013-05-06 17:35:47','<TestDocumentType id=\"1064\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"2\" createDate=\"2013-05-06T18:20:02\" updateDate=\"2013-05-06T18:35:47\" nodeName=\"Products\" urlName=\"products\" path=\"-1,1061,1064\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Products</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Products Page List 234567</p>]]></bodyContent>\r\n</TestDocumentType>'),(1064,'8cd13135-c716-4c0a-8ced-f8aba7bb31f2','2013-05-06 17:35:48','<TestDocumentType id=\"1064\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"2\" createDate=\"2013-05-06T18:20:02\" updateDate=\"2013-05-06T18:35:47\" nodeName=\"Products\" urlName=\"products\" path=\"-1,1061,1064\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Products</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Products Page List 234567</p>]]></bodyContent>\r\n</TestDocumentType>'),(1064,'f9c10a21-668d-4005-8ebf-9e8eb1ee40f3','2013-05-06 17:40:58','<TestDocumentType id=\"1064\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"2\" createDate=\"2013-05-06T18:20:02\" updateDate=\"2013-05-06T18:40:58\" nodeName=\"Products\" urlName=\"products\" path=\"-1,1061,1064\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Products</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Products Page List 234567</p>]]></bodyContent>\r\n</TestDocumentType>'),(1062,'3520c8d1-eee7-4add-aaeb-00041ca2174d','2013-05-06 17:41:15','<TestDocumentType id=\"1062\" parentID=\"1061\" level=\"2\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-05-06T18:15:50\" updateDate=\"2013-05-06T18:41:15\" nodeName=\"About us\" urlName=\"about-us\" path=\"-1,1061,1062\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">About us</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>This is the about us page.</p>]]></bodyContent>\r\n</TestDocumentType>'),(1066,'35c447d8-9fa1-4aa8-afe7-e97908a3583c','2013-05-06 17:41:15','<TestDocumentType id=\"1066\" parentID=\"1062\" level=\"3\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-05-06T18:22:20\" updateDate=\"2013-05-06T18:41:15\" nodeName=\"Our Business\" urlName=\"our-business\" path=\"-1,1061,1062,1066\" isDoc=\"\" nodeType=\"1058\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1059\">\r\n  <title xmlns=\"\">Our Business</title>\r\n  <bodyContent xmlns=\"\"><![CDATA[<p>Our Business page</p>]]></bodyContent>\r\n</TestDocumentType>'),(1074,'0c1ad280-68b8-4b93-9cf2-9332681c3815','2013-06-10 20:50:31','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T21:50:31\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"0\">\r\n  <pageTitle xmlns=\"\"></pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1074,'c41b4ce8-433d-4290-838a-ee12a0cb893d','2013-06-10 20:50:31','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"1\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T21:50:31\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"0\">\r\n  <pageTitle xmlns=\"\"></pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1074,'adaa7989-762c-4224-899f-5840a448b16c','2013-06-10 20:50:42','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T21:50:42\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"0\">\r\n  <pageTitle xmlns=\"\"></pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1074,'03fc47df-df58-4aed-8a42-593dba5a8467','2013-06-10 20:50:42','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T21:50:42\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"0\">\r\n  <pageTitle xmlns=\"\"></pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1074,'fa728a68-36f8-4fad-a738-5e3d19eba52c','2013-06-10 20:51:45','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T21:51:45\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"0\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1074,'5a1a174c-6f84-4c93-b7af-4f33f08e01c5','2013-06-10 20:51:45','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T21:51:45\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"0\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1074,'53a99c2e-3113-402a-a98a-384ebb035723','2013-06-10 20:53:29','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T21:53:29\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1074,'a18add03-8c1e-4b62-b8ac-67e828b92c5f','2013-06-10 20:53:29','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T21:53:29\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1074,'5ad27bbc-16df-4560-97e0-23a71aeb7c3c','2013-06-10 20:53:43','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T21:53:43\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1074,'cf8a3123-00ca-4ac3-b418-d0d6489de38f','2013-06-10 20:53:43','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T21:53:43\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1074,'f4a2ec82-d7a3-45ca-9731-00be1fdc0ec4','2013-06-10 22:55:30','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T23:55:30\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />]]></bodyText>\r\n</TextPage>'),(1074,'9926b88d-d804-44da-97ad-5a95784d8ca2','2013-06-10 22:55:30','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T23:55:30\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />]]></bodyText>\r\n</TextPage>'),(1074,'fa18e13e-6198-4f8c-999c-b8d2a9431063','2013-06-10 22:55:44','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T23:55:44\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />]]></bodyText>\r\n</TextPage>'),(1074,'eb8b6d64-cbec-49ee-b695-7d1de111ca04','2013-06-10 22:55:45','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-10T23:55:45\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />]]></bodyText>\r\n</TextPage>'),(1074,'30ebdca7-b9f5-4447-ac7c-0d2e6a769f22','2013-06-10 23:38:22','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-11T00:38:22\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />]]></bodyText>\r\n</TextPage>'),(1074,'4dc571a4-7358-4fa1-a674-78bfde232e80','2013-06-10 23:38:22','<TextPage id=\"1074\" parentID=\"-1\" level=\"1\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-10T21:50:25\" updateDate=\"2013-06-11T00:38:22\" nodeName=\"Home Page\" urlName=\"home-page\" path=\"-1,1074\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">Upload, Share, Vote ...</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[<?UMBRACO_MACRO macroAlias=\"ImageGalleryMacro\" />]]></bodyText>\r\n</TextPage>'),(1082,'bd69e48b-ab13-4c0b-bd5f-7a7ffefafb8b','2013-06-11 00:46:11','<TextPage id=\"1082\" parentID=\"1074\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-11T01:46:06\" updateDate=\"2013-06-11T01:46:11\" nodeName=\"About Us\" urlName=\"about-us\" path=\"-1,1074,1082\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\"></pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1082,'2d029673-3d4c-40ab-99cc-c302607f786d','2013-06-11 00:46:11','<TextPage id=\"1082\" parentID=\"1074\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-11T01:46:06\" updateDate=\"2013-06-11T01:46:11\" nodeName=\"About Us\" urlName=\"about-us\" path=\"-1,1074,1082\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\"></pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1082,'c9caf9ec-39d9-40f6-ba9b-be9510c621bc','2013-06-11 00:46:19','<TextPage id=\"1082\" parentID=\"1074\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-11T01:46:06\" updateDate=\"2013-06-11T01:46:19\" nodeName=\"About Us\" urlName=\"about-us\" path=\"-1,1074,1082\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">The originals</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1082,'3af08dc3-85d6-4b5c-b21e-7b5e01ae962c','2013-06-11 00:46:19','<TextPage id=\"1082\" parentID=\"1074\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-11T01:46:06\" updateDate=\"2013-06-11T01:46:19\" nodeName=\"About Us\" urlName=\"about-us\" path=\"-1,1074,1082\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">The originals</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[]]></bodyText>\r\n</TextPage>'),(1082,'b6fb195d-f1cc-4af9-a454-933236852aea','2013-06-11 00:47:05','<TextPage id=\"1082\" parentID=\"1074\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-11T01:46:06\" updateDate=\"2013-06-11T01:47:05\" nodeName=\"About Us\" urlName=\"about-us\" path=\"-1,1074,1082\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">The originals</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[<h2>We were serving long before the others...</h2>\r\n<p>Etc., etc.</p>]]></bodyText>\r\n</TextPage>'),(1082,'d36dc3d8-4348-4588-b953-a9cc6cb80f37','2013-06-11 00:47:05','<TextPage id=\"1082\" parentID=\"1074\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-11T01:46:06\" updateDate=\"2013-06-11T01:47:05\" nodeName=\"About Us\" urlName=\"about-us\" path=\"-1,1074,1082\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">The originals</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[<h2>We were serving long before the others...</h2>\r\n<p>Etc., etc.</p>]]></bodyText>\r\n</TextPage>'),(1082,'7d2aefa6-99a8-4f47-ac08-939adf7a83eb','2013-06-11 00:49:14','<TextPage id=\"1082\" parentID=\"1074\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-11T01:46:06\" updateDate=\"2013-06-11T01:49:14\" nodeName=\"About Us\" urlName=\"about-us\" path=\"-1,1074,1082\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">The originals</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[<h2>We were serving long before the others...</h2>\r\n<p>Etc., etc.</p>]]></bodyText>\r\n</TextPage>'),(1082,'2d43400e-8bb5-4318-b54e-c87247898ab5','2013-06-11 00:49:14','<TextPage id=\"1082\" parentID=\"1074\" level=\"2\" creatorID=\"0\" sortOrder=\"0\" createDate=\"2013-06-11T01:46:06\" updateDate=\"2013-06-11T01:49:14\" nodeName=\"About Us\" urlName=\"about-us\" path=\"-1,1074,1082\" isDoc=\"\" nodeType=\"1072\" creatorName=\"admin\" writerName=\"admin\" writerID=\"0\" template=\"1073\">\r\n  <pageTitle xmlns=\"\">The originals</pageTitle>\r\n  <bodyText xmlns=\"\"><![CDATA[<h2>We were serving long before the others...</h2>\r\n<p>Etc., etc.</p>]]></bodyText>\r\n</TextPage>');
/*!40000 ALTER TABLE `cmspreviewxml` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmstask`
--

DROP TABLE IF EXISTS `cmstask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmstask` (
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskTypeId` int(11) NOT NULL,
  `nodeId` int(11) NOT NULL,
  `parentUserId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `DateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Comment` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taskTypeId` (`taskTypeId`),
  KEY `nodeId` (`nodeId`),
  KEY `parentUserId` (`parentUserId`),
  KEY `userId` (`userId`),
  CONSTRAINT `cmstask_ibfk_1` FOREIGN KEY (`taskTypeId`) REFERENCES `cmstasktype` (`id`),
  CONSTRAINT `cmstask_ibfk_2` FOREIGN KEY (`nodeId`) REFERENCES `umbraconode` (`id`),
  CONSTRAINT `cmstask_ibfk_3` FOREIGN KEY (`parentUserId`) REFERENCES `umbracouser` (`id`),
  CONSTRAINT `cmstask_ibfk_4` FOREIGN KEY (`userId`) REFERENCES `umbracouser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmstask`
--

LOCK TABLES `cmstask` WRITE;
/*!40000 ALTER TABLE `cmstask` DISABLE KEYS */;
INSERT INTO `cmstask` VALUES (0,1,1,1066,0,2,'2013-05-06 17:48:09','pls do translate.');
/*!40000 ALTER TABLE `cmstask` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-06-11 23:24:45
